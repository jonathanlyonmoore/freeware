/* 2006-01-26 SMS.
   VMS-specific header associated with vms.c.
*/

#ifndef _VMS_H
#define _VMS_H

/* GETxxI item descriptor structure. */
typedef struct
    {
    short buf_len;
    short itm_cod;
    void *buf;
    int *ret_len;
    } xxi_item_t;

/* Desperation attempts to define unknown macros.  Probably doomed.
 * If these get used, expect sys$getjpiw() to return %x00000014 =
 * %SYSTEM-F-BADPARAM, bad parameter value.
 * They keep compilers with old header files quiet, though.
 */
#ifndef JPI$_RMS_EXTEND_SIZE
#  define JPI$_RMS_EXTEND_SIZE 542
#endif /* ndef JPI$_RMS_EXTEND_SIZE */

#ifndef JPI$_RMS_DFMBC
#  define JPI$_RMS_DFMBC 535
#endif /* ndef JPI$_RMS_DFMBC */

#ifndef JPI$_RMS_DFMBFSDK
#  define JPI$_RMS_DFMBFSDK 536
#endif /* ndef JPI$_RMS_DFMBFSDK */

/* File open callback ID values. */

#  define FOPR_ID 1
#  define FOPW_ID 2

/* File open callback ID storage. */

extern int fopr_id;
extern int fopw_id;

/* File open callback ID function. */

extern int acc_cb();

/* File name version trim function. */

extern void trimFileNameVersion( char *file_name);

/* Basename extraction function. */

extern char *vms_basename( char *file_spec);

/* Wild-card file name expansion function. */

extern char *vms_wild( char *file_spec, int *wild);

#endif /* ndef _VMS_H */

