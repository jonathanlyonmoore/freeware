#!/bin/sh
#                                               30 September 2005.  SMS.
#
# BZIP2 1.0.3
#
#    Restore original file names after storage on an ODS2 file system.
#
mv makefile Makefile
mv license LICENSE
mv bzip2.1_preformatted bzip2.1.preformatted
mv readme README
mv readme.compilation_problems README.COMPILATION.PROBLEMS
mv readme.xml_stuff README.XML.STUFF
mv changes CHANGES
mv y2k_info Y2K_INFO
mv spewg.c spewG.c
mv makefile-libbz2_so Makefile-libbz2_so
#
