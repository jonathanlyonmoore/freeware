* Note from HG: there was a problem displaying the logo on AXP under Motif
  V1.2, so I gave define_logo a value of 0 in CD_PLAYER.C.  Feel free to
  change that to 1 and try it in your environment.....
--------------------
    CD_PLAYER is a program to allow playing of Audio CDs on CD-Rom drives
capable of doing so. It is written in C and uses the Motif user interface.
Because it needs to access the SCSI device directly, it requires DIAGNOSE and
PHY_IO privilege to execute (note, you may INSTALL the program with these
privileges). You need to define the logical name "DECW$CD_PLAYER" to point to
the device which you wish to us. You can use the procedure VUE_CD_PLAYER.COM,
which will put up a requestor to select the drive if you haven't already
defined the logical.

   The current version of CD_PLAYER supports an Album database for album
titles & track lengths and an auxiliary database for songs for the albums,
which can store track titles and whether a track is preferred (a simple
playlist). The files SYS$LOGIN:ALBUM.CD and SONGS.DB are indexed files whose
current and future structure is outlined in CD-DB.C.

   Future support will hopefully include an Artist DB, as well as a
"Prefered track" DB and logical song groupings in the songs DB.
 
   If you already have used a previous version of this program, you may have
an album database which may need converting to the current format via the
included ALBUM.FDL & CONVERT.COM files.

   All feedback is quite welcome: send correspondence to one of the addresses
below. Please bear in mind that this is a work in progress: if you have access
to the Internet, you can get up-to-date versions by asking!

   Thank you for your interest in this program, I hope it proves useful
(well, at least fun). 

Joe Meadows
meadowsj@boeing.com
or joe@kirk.fhcrc.org 

Ian Kitching		     Computer Services, Anglia Polytechnic University
systimk@va.anglia.ac.uk	     East Rd, Cambridge, CB1 1PT, England
Phone: +44 223 63271 x 2278  Fax: +44 223 352973

-----------------------------------------------------------------------------

		Getting This Going
		==================

   (There are compile-time options - see below.)

   Copy CD_PLAYER.EXE and VUE_CD_PLAYER.COM to VUE$LIBRARY_WRITE:
(this is the "customer" part of the VUE$LIBRARY search list).
If you choose to put the .EXE elsewhere, edit the .COM accordingly.

   Copy CD_PLAYER.DAT to DECW$USER_DEFAULTS:, which is usually the same as
SYS$LOGIN:.

   Consider installing the .EXE with DIAGNOSE & PHY_IO privileges. The
alternative is for the process created by the Session Manager to have these
privileges.

   Consider defining the DECW$CD_PLAYER logical name, ideally as a Exec-mode
system one. However the VUE procedure pops up a device name prompt if the
DECW$CD_PLAYER logical name is undefined.

   Define a Session Manager menu item to invoke "@VUE$LIBRARY:VUE_CD_PLAYER".

   Launch CD_PLAYER and check that the defaults supplied in CD_PLAYER.DAT are
appropriate for you. In particular you may wish to resize the main window and
save the size via the Options pull-down menu.

-----------------------------------------------------------------------------

		Installing with DIAGNOSE & PHY_IO Privileges
		============================================

   If you choose to install the program with DIAGNOSE & PHY_IO, there are
compile-time options in CD-UTIL.C for safety checks on the DECW$CD_PLAYER
logical name.

   You can choose to ensure it's an Executive-mode system one or that it's in
the system table. As supplied it performs a standard Exec-mode-only check.

   If the check fails the program turns off its installed privileges, leaving
just the process permanent privileges.

   There are also optional checks on the device type (see below).

-----------------------------------------------------------------------------

		Compiling & Linking
		===================

   See MAKE.COM and/or MAKEFILE. for compiling and linking this.

   The most recent phase of development has been with OpenVMS/VAX V5.5 and
Motif V1.1.  Link options for Motif V1.0 and V1.2 are supplied.

-----------------------------------------------------------------------------

		Device Support
		==============

   As of VMS V5.4-3(?) the normal SCSI disk device driver supports the necessary
functions. Prior to that one had to use the generic SCSI device driver - see
SYCONFIG.COM for hints.

   This has only been tested with DEC's RRD42 drive, which appears not to
support software volume control.

   The module CD-UTIL.C has compile-time options for checking the VMS device
class and/or type. As supplied these checks are disabled. It always performs
the CD type check. If the device type check fails it disables any image
privileges, leaving just the process permanent privileges.
