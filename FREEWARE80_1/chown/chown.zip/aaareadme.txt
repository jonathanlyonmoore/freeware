CHOWN - Unix-like VMS 'chown' Facility
(c) Copyright 1991-1996, Chris Olive
------------------------------------------------------------------------------

As with most utilities, CHOWN was created  out  of  necessity.   I  wanted  to
change the ownership of INDEXF.SYS and QUOTA.SYS once, and wouldn't take 'No!'
for an answer.   So  CHOWN  was  born.   Since  these  files,  INDEXF.SYS  and
QUOTA.SYS,  are  locked, SET FILE/OWNER= won't cut it -- CHOWN works in places
where SET FILE/OWNER just won't.  And not wanting to write a hack when I might
need the same functionality on something else down the line, I generalized the
functionality into this utility.  It's called 'chown' not because I like  Unix
(but  if  I  weren't  running  VMS, I'd probably run Unix -- anything but that
pretender Windoze and MS-DUM...) but  that's  just  what  I  named  it,  okay?
Actually, the parameters CHOWN requires are much like Unix, that's why:

Syntax:  CHOWN rights-id-string filespec

The 'rights-id-string' is the name of  a  rights  identifier  on  the  system.
Since  every  user  has (should have!) a rights identifier associated with his
name, CHOWN can be used to set the ownership of a file(s) to any user  on  the
system.  If you have by chance *removed* the associated rights id string for a
user, then this utility makes you pay for such an ignorant move --  you  won't
be  able to use CHOWN!  Base resource numbers inside brackets (i.e.  [1,4] for
SYSTEM) and bracket delimited rights id strings (i.e.   [SYSTEM]  for  SYSTEM)
WILL  NOT  WORK!   DON'T  USE  BRACKETS!  Also, CHOWN handles what 'chown' and
'chgrp' do on Uglix since VMS doesn't allow the same rights id  string  to  be
granted  to  two  different  group  UIC  strings  (e.g.   you  can't  have  an
[ORDER,FOO] and a [SALES,FOO] in VMS).  So the 'rights-id=string' is all  that
is needed and it doesn't need brackets, just like Uglix.

The 'filespec' is exactly what a filespec is in  any  other  VMS  facility  or
utility.  CHOWN can change to the ownership of all files that match a wildcard
filespec, including [...]*.*;*

For you curious more technical types out there, CHOWN works using the  ACP-QIO
interface.   You need a FIB and an ATR (attribute) item list; you fill the FIB
with a file's file id (FID); and,  with  a  channel  assigned  to  the  file's
device,  $QIO using IO$MODIFY.  Magic.  Poof.  New owner.  Locks?  What locks?
(The ATR item list tells $QIO to change  the  file's  owner  to  the  UIC  you
specify).

That's about it.  Happy 'chown'ing...
------------------------------------------------------------------------------
Chris Olive
...still a VMS programmer at heart...
73740.1636@compuserve.com
