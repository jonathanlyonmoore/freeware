CLEAR_ERRORS clears the device error count on an Alpha VMS system.
Files in this contribution include:

AAAREADME.TXT     - this file
BLD.COM           - procedure to build CLEAR_ERRORS exe
CLEAR_ERRORS.C    - source
CLEAR_ERRORS.EXE  - executable
CLEAR_ERRORS.OBJ  - compiled source
SET_ERRORS.C      - program to set error count for each device
SET_ERRORS.EXE    - executable
SET_ERRORS.OBJ    - compiled source
SYSDOC.TXT        - system documentation

SET_ERRORS is included because it was useful for testing
and debugging CLEAR_ERRORS. 

Special thanks to Norm Raphael who corrected grammar, misspellings, and
formatting in the SYSDOC.TXT

Questions and comments are welcome. 

Mark Oakley
Verizon Wireless
5165 Emerald Parkway
Dublin, OH  43017

614/560-8726
mark.oakley@verizonwireless.com

