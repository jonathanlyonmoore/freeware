
This package illustrates how to implement privileged shareable images, with
user-written system services in C and other high-level languages.  It includes
a generic change mode dispatcher that can be reused for any privileged
shareable image, sample system services, and a sample program using those
services.

This package was run through zip, mftu, and vms_share.  If you do not have zip
or mftu, issue a "send fileserv_tools" command to the file server.

For further information about the package, read dispatcher.txt.

This is version 1.0 of Dispatch.

