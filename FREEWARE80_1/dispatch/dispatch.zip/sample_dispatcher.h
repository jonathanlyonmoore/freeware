typedef struct { unsigned long lo;
                 unsigned long hi; } Date;


/************************************************************************/
/*									*/
/*									*/
/*    get_system_time(system_time,first_time)				*/
/*									*/
/*    This routine executes in kernel mode 				*/
/*									*/
/************************************************************************/

long get_system_time(Date *system_time,Date *first_time);

/************************************************************************/
/*									*/
/*									*/
/*    lock_pages()							*/
/*									*/
/*    This routine executes in kernel mode 				*/
/*									*/
/************************************************************************/

long lock_pages(void);

/************************************************************************/
/*									*/
/*									*/
/*    unlock_pages()							*/
/*									*/
/*    This routine executes in kernel mode 				*/
/*									*/
/************************************************************************/

long unlock_pages(void);

