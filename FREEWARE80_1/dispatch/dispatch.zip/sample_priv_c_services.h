
/************************************************************************/
/*									*/
/*									*/
/*    get_data_from_channel_number(channel_number,ucb, vcb, ddt, ccb)	*/
/*									*/
/*    This routine executes in kernel mode 				*/
/*									*/
/************************************************************************/

long get_data_from_channel_number(short int channel_number,long *ucb_addr,
		long *vcb_addr, long *ddt_addr, long *ccb_addr);

/************************************************************************/
/*									*/
/*									*/
/*    get_my_pcb_address(pcb)						*/
/*									*/
/*    This routine executes in kernel mode 				*/
/*									*/
/************************************************************************/

long get_my_pcb_address(long *pcb_address);


/************************************************************************/
/*									*/
/*									*/
/*    get_my_phd_address(phd)						*/
/*									*/
/*    This routine executes in kernel mode 				*/
/*									*/
/************************************************************************/

long get_my_phd_address(long *phd_address);


