
/************************************************************************/
/*									*/
/*									*/
/*    print_control_block_address(block,what)				*/
/*									*/
/*    This routine executes in user mode 				*/
/*									*/
/************************************************************************/

void print_control_block_address(long block,char what[]);


/************************************************************************/
/*									*/
/* get_date_time_string(date_time_quad,date_time_string)		*/
/*									*/
/*    This routine executes in user mode 				*/
/*									*/
/************************************************************************/

long get_date_time_string(Date date_time_quad, char date_time_string[]);

/************************************************************************/
/*									*/
/* assign_channel (dev_name,flags)					*/
/*									*/
/*    This routine executes in user mode 				*/
/*									*/
/************************************************************************/

long assign_channel (char dev_name[],long flags);

