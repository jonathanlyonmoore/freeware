#ifdef VMS
#define ftell vms_ftell
#define fseek vms_fseek
#define getchar vms_getchar
#define getenv vms_getenv
#define ungetc vms_ungetc
#define getname vms_getname
#endif /* VMS */
