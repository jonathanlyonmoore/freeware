/* Program Name            : DIRECTKPD.H                                */
/*   Original Author       : C. K. Hung					*/
/*   Date                  : 7-JUN-1991 				*/
/*   Program Description   :                                            */  
/*                         :                                            */ 
/* References                                                           */
/*   Files open for Input  :                                            */ 
/*   Files open for Output :                                            */ 
/*   Modules Referenced    :                                            */ 
/* Revision History follows                                             */


/* ****	FUNCTION PROTOTYPING *** */

int	dirtree_find_first(void);
int	dirtree_find_first$1(char *, char *, char *);
int	dirtree_find_next(void);
int	change_dirtree_viewport(int, int, int *, int *);
void	find_down(TD_NODE_TAG *, TD_NODE_TAG *, TD_NODE_TAG **, int *);
TD_NODE_TAG *find_right(TD_NODE_TAG *);
TD_NODE_TAG *find_left(TD_NODE_TAG *);
TD_NODE_TAG *dirtree_page_down(TD_NODE_TAG *, TD_NODE_TAG *);
TD_NODE_TAG *search_node_page (TD_NODE_TAG *, int, int);
TD_NODE_TAG *dirtree_page_up (TD_NODE_TAG *);
int	direct_initial(void);

