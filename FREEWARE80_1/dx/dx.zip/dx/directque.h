/*
**++
**  FACILITY:
**
**	    DIRECTQUE.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      24-SEP-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**  INCLUDE FILES
**
**/

/*
**
**  GLOBAL DECLARATIONS
**
**/

#define		MAX_DIRECT_BUFFER	20	/**  Size of the dir cache   **/

struct root_equ_names_tag
    {
	char equ_name[MAXFILESPEC+1];		/**  Equivalent name	     **/
	struct root_equ_names_tag *next;	/**  Next name		     **/
    };

struct direct_cache_tag
    {
	DATE_TIME time_stamp;			/**  Last access time	     **/
	struct root_equ_names_tag *root_equ_names;
						/**  Root directories	     **/
	enum directions direction;		/**  Search direction	     **/
	char pattern[MAXFILESPEC+1];		/**  Search pattern	     **/
	struct node_tag *root;			/**  Directory tree head     **/
    } direct_cache[MAX_DIRECT_BUFFER];   /**  Buffer to save directory info  **/

/*
**
**  FUNCTIONS PROTOTYPING
**
**/

    int			    initialize_direct_cache(void);
    int			    find_LRU_in_direct_cache(void);
    int			    search_direct_cache(char *);
    int			    save_to_direct_cache(int, char *, enum directions, 
				char *, struct node_tag *);
    int			    restore_from_direct_cache(int, 
				enum directions *, char *, struct node_tag **);
    int			    add_to_direct_cache(char *, char *);
    int			    delete_from_direct_cache(char *, char *);
