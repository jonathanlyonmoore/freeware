/*
**++
**  FACILITY:
**
**	    ENDECODE.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      1-JUN-1990
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**  INCLUDE FILES
**
**/

#include stdio

/*
**	MACRO DEFINITIONS
**/

#define BITS			12
#define HASHING_SHIFT		(BITS-8)
#define MAX_VALUE		((1 << BITS)-1)
#define MAX_CODE		(MAX_VALUE-1)

#if BITS == 14
#define TABLE_SIZE		18041
#elif BITS == 13
#define TABLE_SIZE		9029
#elif BITS == 12
#define TABLE_SIZE		5021
#endif

/*
**
**  GLOBAL DECLARATIONS
**
**/

int		*code_value;
unsigned int	*prefix_code;
unsigned char	*append_character;
unsigned char	decode_stack[4000];

/*
**
**  FUNCTIONS PROTOTYPING
**
**/

    int			    compress (FILE *input, FILE *output);
    int			    find_match (int hash_prefix, unsigned int hash_character);
    int			    output_code (FILE *output, unsigned int code);

    int			    expand(char *errmsg, FILE *input, FILE *output);
    char		    *decode_string(char *, unsigned char *buffer, unsigned int code);
    int			    input_code(FILE *input);
