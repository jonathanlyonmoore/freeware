/*
**++
**  FACILITY:
**
**	FILERAPP.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      22-OCT-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_append(void);
    int		    filer_multiple_append(void);
    int		    filer_single_append(void);
    int		    filer_append$1(char *, char *, char *);
    int		    change_to_filer(struct fil_dx_tag, char *, unsigned short);
