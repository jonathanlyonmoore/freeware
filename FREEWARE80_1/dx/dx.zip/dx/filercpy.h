/*
**++
**  FACILITY:
**
**	FILERCPY.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      21-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_copy(void);
    int		    filer_multiple_copy(void);
    int		    filer_single_copy(void);
    int		    filer_copy$1(char *, char *, char *);
    int		    add_to_filer(struct fil_dx_tag, char *, unsigned short int);
