/*
**++
**  FACILITY:
**
**	DIRECTCUS Global Function Prototyping
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      8-JAN-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**	FUNCTION PROTOTYPING
**
**/

int		    custom_editor(void);
int		    select_a_editor(char *, char *, char *);

int		    custom_display_date(void);
int		    select_a_display_date(char *, char *, char *);

int		    custom_delete(void);
int		    confirm_delete(char *, char *, char *);

int		    custom_purge(void);
int		    confirm_purge(char *, char *, char *);

int		    custom_type(void);
int		    select_type_method(char *, char *, char *);

int		    custom_term_rows(void);
int		    set_term_rows(char *, char *, char *);

int		    custom_auto_update(void);
int		    auto_update(char *, char *, char *);

int		    custom_display_clock(void);
int		    display_clock(char *, char *, char *);

int		    custom_update_in_second(void);
int		    update_in_second(char *, char *, char *);

int		    custom_save_setting(void);
int		    save_setting(char *, char *, char *);

int		    custom_restore_setting(void);
int		    restore_setting(char *, char *, char *);

int		    custom_use_default(void);
int		    use_default(char *, char *, char *);

