/*
**++
**  FACILITY:
**
**	    FILERDEC.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      1-JUN-1990
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**  FUNCTIONS PROTOTYPING
**
**/

    int			    filer_decode(void);
    int			    filer_multiple_decode(void);
    int			    filer_single_decode(void);
    int			    filer_decode$1(char *, char *, char *);
