/*
**++
**  FACILITY:
**
**	FILERDEL.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      20-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_delete(void);
    int		    filer_multiple_delete(void);
    int		    filer_single_delete(void);
    int		    filer_delete$1(char *, char *, char *);
    int		    filer_delete$2(char *, char *, unsigned short int);
    int		    recompute_filer_beg_xy(struct fil_dx_tag *, int, int, unsigned short);
