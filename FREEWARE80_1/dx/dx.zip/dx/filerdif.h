/*
**++
**  FACILITY:
**
**	FILERDIF.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      18-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_diff(void);
    int		    filer_multiple_diff(void);
    int		    filer_single_diff(void);
    int		    filer_diff$1(char *, char *, char *);
