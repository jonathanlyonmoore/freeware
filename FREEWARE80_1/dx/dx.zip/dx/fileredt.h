/* Program Name            : FILEREDT.H                                                     */
/*   Original Author       : C. K. Hung							    */
/*   Date                  : 18-MAY-1991                                                    */
/*   Program Description   :                                                                */  
/*                         :                                                                */ 


int		    filer_edt(void);
int		    filer_multiple_edt(void);
int		    filer_single_edt(void);
int		    filer_edt$1(char *, char *, char *);

