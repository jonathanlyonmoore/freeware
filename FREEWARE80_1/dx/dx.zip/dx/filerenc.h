/*
**++
**  FACILITY:
**
**	    FILERENC.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      1-JUN-1990
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**  FUNCTIONS PROTOTYPING
**
**/

    int			    filer_encode(void);
    int			    filer_multiple_encode(void);
    int			    filer_single_encode(void);
    int			    filer_encode$1(char *, char *, char *);

    int			    filestat(char *, struct fil_dx_tag *, char *);
