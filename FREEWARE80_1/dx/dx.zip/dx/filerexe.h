/*
**++
**  FACILITY:
**
**	FILEREXE.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      3-AUG-1990
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**	FUNCTION PROTOTYPING
**
**/

    int		    filer_vms_gateway(void);
    int		    filer_vms_command(void);
    int		    vms_command(char *, char *, char *);
