/*
**++
**  FACILITY:
**
**	FILERFLT.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      3-AUG-1990
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**	FUNCTION PROTOTYPING
**
**/

    int             filer_filter_name(void);

    int             filer_filter_exclude(void);
    int             filter_exclude(char *, struct fil_dx_tag *);

    int             filer_filter_since(void);
    int             filter_since(DATE_TIME, DATE_TIME);

    int             filer_filter_before(void);
    int             filter_before(DATE_TIME, DATE_TIME);

    int             filer_filter_maximum(void);
    int             filter_maximum(unsigned int, unsigned int);

    int             filer_filter_minimum(void);
    int             filter_minimum(unsigned int, unsigned int);

    int		    filter_OK(struct fil_dx_tag, struct fil_dx_tag *, struct cur_filter_tag);
    int		    filer_filter$1(char *, char *, char *);

    int		    free_filespec_list(struct filespec_list_tag **);
