/*
**++
**  FACILITY:
**
**	FILERFND.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      18-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_find(void);
    int		    filer_multiple_find(void);
    int		    filer_single_find(void);
    int		    filer_find$1(char *, char *, char *);
