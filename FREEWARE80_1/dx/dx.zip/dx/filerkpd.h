/*
**++
**  FACILITY:
**
**	    FILERKPD.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      20-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**	FUNCTION PROTOTYPING
**
**/
    int		    change_filer_viewport(unsigned short int);
    int		    filer_top(void);
    int		    filer_bottom(void);
    int		    filer_page_down(void);
    int		    filer_page_up(void);
    int		    filer_up(void);
    int		    filer_down(void);
    int		    filer_find_first(void);
    int		    filer_find_first$1(char *, char *, char *);
    int		    filer_find_next(void);
    int		    filer_mark(struct fil_dx_tag *, int);
    int		    filer_unmark(struct fil_dx_tag *, int);
    int             filer_execute(struct fil_dx_tag *);
    int		    filer_multiple(int (*)(), char *, char *);
