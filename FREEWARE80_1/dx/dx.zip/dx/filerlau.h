/*
**++
**  FACILITY:
**
**	FILERLAU.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      18-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_launch(void);
    int		    filer_multiple_launch(void);
    int		    filer_single_launch(void);
    int		    filer_launch$1(char *, char *, char *);
