/* Program Name            : FILEROPT.H                                 */
/*   Original Author       : C. K. Hung					*/
/*   Date                  : 3-AUG-1990					*/
/*   Program Description   :                                            */  
/*                         :                                            */ 
/* Revision History follows                                             */

/* ****	MACRO DEFINITIONS *** */
#define DXVERSION "DX Version 2.5 03-Jun-1999, by C.K. Hung & J. Lauret"


/* ****	FUNCTION PROTOTYPING *** */

int	filer_update(void);
int	filer_help(char *);
int     filer_write(void);
int     print_filer_display(char *, char *, char *);
int     filer_goto(void);
int     filer_goto$1(char *, char *, char *);
int     filer_mark_all(void);
int     filer_unmark_all(void);
int     filer_remark_all(void);
int	filer_short_form(void);
int	filer_long_form(void);
int	get_quota(unsigned long);
int	filer_about(void);
int     filer_mkdir(void);
int     filer_mkdir$1(char *, char *, char *);
int	filer_show_buffer(void);


