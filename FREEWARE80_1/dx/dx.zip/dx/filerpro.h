/*
**++
**  FACILITY:
**
**	FILERPRO.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      17-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_protection(void);
    int		    filer_multiple_protection(void);
    int		    filer_single_protection(void);
    int		    filer_protection$1(char *, char *, char *);
    int		    chprot(char *, char *, char *, unsigned short *);
    int		    getprotbits(char *, unsigned short *, unsigned short *);
