/*
**++
**  FACILITY:
**
**	FILERPRT.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      17-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_print(void);
    int		    filer_multiple_print(void);
    int		    filer_single_print(void);
    int		    filer_print$1(char *, char *, char *);
