/*
**++
**  FACILITY:
**
**	FILERPUR.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      21-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_purge(void);
    int		    filer_multiple_purge(void);
    int		    filer_single_purge(void);
    int		    filer_purge$1(char *, char *, char *);
