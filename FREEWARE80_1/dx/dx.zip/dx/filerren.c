/* Program Name            : FILERREN.C                                 */
/*   Original Author       : C. K. Hung 				*/
/*   Date                  : 30-MAY-1991				*/
/*   Program Description   :                                            */
/*                         :                                            */
/* Revision History follows                                             */
 
#include "global.h"
#include "dx.h"
#include "filer.h"
#include "filercpy.h"
#include "filerdel.h"
#include "filerque.h"
#include "filerren.h"
#include "inquire.h"
 
 

/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**      tbs
**
**--
**/
int	filer_rename()
{
    if (DX_CURRENT_DIRECTORY.filemode == multiple)
	filer_multiple_rename();
    else
	filer_single_rename();
     return DX__NORMAL;
}
 
 
/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**      to be specified
**
**--
**/
int	filer_multiple_rename()
{
    char errmsg[MAXFILESPEC+1];
 
    strcpy(errmsg, "Error renaming file");
    multi_get_userinput_and_exec(
	filer_rename$1,
	"Multiple Rename",
	"Rename to: ",
	"",
	errmsg);
     return DX__NORMAL;
}
 
 

/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**      to be specified
**
**--
**/
int	filer_single_rename()
{
    char errmsg[MAXFILESPEC+1];
    char fn[MAXFILESPEC+1];
 
    if (!strcmp(DX_CURRENT_FILE->fn, "[-]"))
    {
        signal_err("Type a parent directory file not allowed", bell);
    }
    else
    {
	find_full_path_name(DX_CURRENT_FILE->fn, fn, cntrl_info_block.cur_win);
	strcpy(errmsg, "Error renaming file");
	get_userinput_and_execute(
	    filer_rename$1,
	    "Rename File",
	    "New name: ",
	    "",
	    errmsg,
	    fn);
    }
     return DX__NORMAL;
}
 
 

/*
**++
**  FUNCTIONAL DESCRIPTION:
**
**      to be specified
**
**--
**/
int	filer_rename$1(to, from, errmsg)
char *to;
char *from;
char *errmsg;
{
    struct FAB from_fab;
    struct FAB to_fab;
    struct NAM to_nam;
    char dna[NAM$C_MAXRSS];
    char resultant_name[NAM$C_MAXRSS];
    char *cp;
    long int i;
    struct fil_dx_tag *f;
    struct fil_dx_tag temp_entry;
    int status;
    char direct_name[MAXFILESPEC+1];
 
    /*
    **	Make sure this file is not a directory file that is being
    **	used by the other window
    **/
 
    if (DX_CURRENT_FILE->fn[strlen(DX_CURRENT_FILE->fn) - 1] == ']')
    {
	int i;
	struct filespec_list_tag *p;
	struct w_dids_tag *q;
 
	/**  Update other windows  **/
	for (i = 0;  i < cntrl_info_block.windows;  i++)
	{
	    if (i != cntrl_info_block.cur_win)
	    {
		for (p = cntrl_info_block.dir_dx[i].cur_filter.name_filespec_list;
		     p;  p = p->next)
		{
		    for (q = p->w_dids;  q;  q = q->next)
		    {
			if (q->did[0] == DX_CURRENT_FILE->fid[0] &&
			    q->did[1] == DX_CURRENT_FILE->fid[1] &&
			    q->did[2] == DX_CURRENT_FILE->fid[2])
			{
			    strcpy(errmsg, "File in use by other window - renaming failed");
			    return DX__ERROR;
			}
		    }
		}
	    }
	}
    }
 
    /*
    **	Get old file characteristics before delete it.
    **/
 
    temp_entry.filesize = DX_CURRENT_FILE->filesize;
    memcpy(&(temp_entry.cdat), &DX_CURRENT_FILE->cdat, sizeof (DATE_TIME));
    memcpy(&(temp_entry.rdat), &DX_CURRENT_FILE->rdat, sizeof (DATE_TIME));
    memcpy(&(temp_entry.edat), &DX_CURRENT_FILE->edat, sizeof (DATE_TIME));
    memcpy(&(temp_entry.bdat), &DX_CURRENT_FILE->bdat, sizeof (DATE_TIME));
    temp_entry.fpro = DX_CURRENT_FILE->fpro;
    temp_entry.state = waiting;
    temp_entry.beg_y = temp_entry.beg_x = 0;
    temp_entry.forward = temp_entry.backward = NULL;
 
    /*
    **	Use RMS service to rename the file so that after completion,
    **	we can get the new full file specification.
    **/
 
    from_fab = cc$rms_fab;
    to_fab = cc$rms_fab;
    to_nam = cc$rms_nam;
 
    from_fab.fab$l_fna = from;
    from_fab.fab$b_fns = strlen(from);
 
    strcpy(dna, from);
    cp = strchr(dna, ';');
    *cp = EOS;
 
    to_fab.fab$l_fna = to;
    to_fab.fab$b_fns = strlen(to);
    to_fab.fab$l_dna = dna;
    to_fab.fab$b_dns = strlen(dna);
    to_fab.fab$l_nam = &to_nam;
 
    to_nam.nam$l_rsa = &resultant_name;
    to_nam.nam$b_rss = NAM$C_MAXRSS;
 
    if (sys$rename (
	    &from_fab,
	    0,
	    0,
	    &to_fab) != RMS$_NORMAL)
    {
	sprintf(errmsg, "Error renaming %s", from);
	return DX__ERROR;
    }
 
    for (i = 0;  i <= 2;  i++)
    {
	temp_entry.fid[i] = to_nam.nam$w_fid[i];
	temp_entry.did[i] = to_nam.nam$w_did[i];
    }
    resultant_name[to_nam.nam$b_rsl] = EOS;
    strcpy(temp_entry.fn, strchr(resultant_name, ']')+1);
 
    /*
    **	Delete the file from the filer and udate the screen by
    **	first deleting the renamed file and then adding the new file
    **	to the filer if it is also in current directory.
    **/
 
    check_OK(smg$begin_pasteboard_update (
                 &cntrl_info_block.pasteboard_id))
 
    status = DX__ERROR;
    if (filer_delete$2(from, errmsg, cntrl_info_block.cur_win) != DX__ERROR)
    {
	/*
	**  Update the cache queue.
	**  Only the file name field needs to be changes.
	**/
 
	update_filer_cache(temp_entry, add_to_filer_cache, errmsg);
 
	/*
	**  Update directory queue if the file renamed is a
	**  directory file
	**/
 
	if (strlen(from) > 6 && !strcmp(from+strlen(from)-6, ".DIR;1"))
	{
	    /**  Delete the previous directory from cache  **/
	    strcpy(direct_name, from);
	    cp = strchr (direct_name, ']');
	    *cp = '.';
	    cp = strrchr (direct_name, '.');
	    *cp++ = ']';
	    *cp = EOS;
	    delete_from_direct_cache(direct_name, errmsg);
	
	    /**  Add the new directory to cache  **/
            strcpy(direct_name, resultant_name);
	    cp = strchr (direct_name, ']');
	    *cp = '.';
	    cp = strrchr (direct_name, '.');
	    *cp++ = ']';
	    *cp = EOS;
	    add_to_direct_cache(direct_name, errmsg);
	}
 
	/**  Add it to the FILER  **/
	if (add_to_filer(
		temp_entry, errmsg, cntrl_info_block.cur_win) != DX__ERROR)
	{
	    status = DX__NORMAL;
 
	    /**  Update other windows  **/
	    for (i = 0;  i < cntrl_info_block.windows;  i++)
	    {
		if (i != cntrl_info_block.cur_win)
		{
		    if (filer_delete$2(from, errmsg, i) != DX__ERROR)
		    {
			status = add_to_filer(temp_entry, errmsg, i);
		    }
		}
	    }
	}
    }
 
    check_OK(smg$end_pasteboard_update (
                 &cntrl_info_block.pasteboard_id))
 
    return status;
}
