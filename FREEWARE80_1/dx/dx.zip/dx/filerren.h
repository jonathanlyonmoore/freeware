/*
**++
**  FACILITY:
**
**	FILERREN.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      30-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_rename(void);
    int		    filer_multiple_rename(void);
    int		    filer_single_rename(void);
    int		    filer_rename$1(char *, char *, char *);
