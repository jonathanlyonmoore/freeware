/*
**++
**  FACILITY:
**
**	FILERSRT.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      3-AUG-1990
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**	FUNCTION PROTOTYPING
**
**/

    int             filer_sort_name(void);
    int             filer_sort_type(void);
    int             filer_sort_date(void);
    int             filer_sort_size(void);
    int             filer_sort_mark(void);
    int             filer_sort$1(char *, char *, char *);
    int		    sort_by_dir(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_name(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_type(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_size(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_credate(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_revdate(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_expdate(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_bakdate(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
    int		    sort_by_mark(struct fil_dx_tag *, struct fil_dx_tag *, enum sortorders);
