/*
**++
**  FACILITY:
**
**	FILERSTA.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      16-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

    int		    filer_status(void);
    int		    filer_multiple_status(void);
    int             filer_single_status(void);
    int             filer_status$1(char *, char *, char *);
    void            getpro(unsigned short, char *, char *, char *, char *);
