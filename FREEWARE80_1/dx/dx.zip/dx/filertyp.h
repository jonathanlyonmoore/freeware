/*
**++
**  FACILITY:
**
**	FILERTYP.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      16-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**  MACRO DEFINITIONS
**/

/**  FILER_TYPE1 virtual display dimensions	**/
#define FILER_TYPE1_RIGHTMOST			80
#define FILER_TYPE1_PBD_ROW			1
#define FILER_TYPE1_PBD_COLUMN			1

/**  FILER_TYPE2 virtual display dimensions	**/
#define FILER_TYPE2_BOTTOM			2
#define FILER_TYPE2_RIGHTMOST			80
#define FILER_TYPE2_PBD_COLUMN			1

/*
**  GLOBAL FUNCTION PROTOTYPING
**/

    int		    filer_type(void);
    int		    filer_multiple_type(void);
    int		    filer_single_type(void);
    int		    filer_type$1(char *, char *, char *);
    int		    filer_type$2(char *, char *, char *, int (*)());
