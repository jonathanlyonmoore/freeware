/*
**++
**  FACILITY:
**
**	FILERWIN.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      1-MAY-1991
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**	FUNCTION PROTOTYPING
**
**/

    int		    filer_split_win(void);
    int		    filer_delete_win(void);
    int		    filer_one_win(void);
    int		    filer_next_win(void);
    int		    filer_prev_win(void);
    void	    filer_exitset(void);
