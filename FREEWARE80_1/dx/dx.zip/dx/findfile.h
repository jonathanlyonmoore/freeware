/* Program Name            : FINDFILE.H                                 */
/*   Original Author       : C. K. Hung					*/
/*   Date                  : 20-APR-1990				*/
/*   Program Description   :                                            */  
/*                         :                                            */ 
/* Revision History follows                                             */
/*    03-Jun-1999 JL fix the typdef					*/


/* ****	FUNCTION PROTOTYPING *** */
int		    find_direct_file(void);
int		    find_non_direct_file(void);
int		    find_exclude_file(
			struct fil_dx_tag **, struct cur_filter_tag,
			enum sortbys, enum sortorders);
int		    find_match_file(char *, unsigned short int);
int		    find_queue_file(unsigned short *, TD_FILER_CACHE_TAG *);
struct fil_dx_tag *create_MARKER(void);
int		    add_filelist_entry(
			struct fil_dx_tag *, struct fil_dx_tag *, 
			struct fil_dx_tag *);
int		    free_filelist(struct fil_dx_tag **);
int		    remove_filelist_entry(struct fil_dx_tag **);
int		    insert_filelist_entry(
			struct fil_dx_tag *, struct fil_dx_tag, 
			enum sortbys, enum sortorders);

