/*
**++
**  FACILITY:
**
**	INQUIRE.H
**
**  ABSTRACT:
**
**	[@tbs@]...
**
**  AUTHORS:
**
**      C. K. Hung
**
**
**  CREATION DATE:      20-APR-1990
**
**  MODIFICATION HISTORY:
**
**--
*/

/*
**
**  MACRO DEFINITIONS
**
**/

/**  USERINPUT virtual display dimensions  **/
#define USERINPUT_BOTTOM		10
#define USERINPUT_RIGHTMOST		80
#define USERINPUT_PASTEBOARD_COLUMN	1

/*
**  GLOBAL DECLARATIONS
**/

enum rings		    /**  Instruct SIGNAL_ERR() to ring a bell	     **/
    {
	bell, silence
    };

/*
**
**	FUNCTION PROTOTYPING
**
**/
    int		    get_userinput_and_execute(int (*)(), char *, char *, char *, char *, char *);
    int		    signal_err(char *, enum rings);
    int		    multi_get_userinput_and_exec(int (*)(), char *, char *, char *, char *);
    int		    inquire_alarm_working(void);
