/* Included by: COMMAND EDIT INQUIRE MATCH_SEARCH
Requires: buffer.h rec.h */
extern buf_node CHARBUF;
extern buf_node WORDBUF;
extern buf_node LINEBUF;
extern buf_node KILLBUF;
extern buf_node SEARCHBUF;
