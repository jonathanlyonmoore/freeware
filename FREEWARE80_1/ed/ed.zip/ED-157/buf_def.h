buf_node CHARBUF={0,0,(rec_ptr)&CHARBUF.first,(rec_ptr)&CHARBUF.first};
buf_node WORDBUF={0,0,(rec_ptr)&WORDBUF.first,(rec_ptr)&WORDBUF.first};
buf_node LINEBUF={0,0,(rec_ptr)&LINEBUF.first,(rec_ptr)&LINEBUF.first};
buf_node KILLBUF={0,0,(rec_ptr)&KILLBUF.first,(rec_ptr)&KILLBUF.first};
buf_node SEARCHBUF={0,0,(rec_ptr)&SEARCHBUF.first,(rec_ptr)&SEARCHBUF.first};
