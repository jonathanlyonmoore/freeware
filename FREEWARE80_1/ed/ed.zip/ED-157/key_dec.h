/* Included in: cfg load_key */
extern Char *keyname[];	/* key names for LOAD and UNLOAD commands */
