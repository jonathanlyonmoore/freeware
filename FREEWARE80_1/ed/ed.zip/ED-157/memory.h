#ifdef VMS
#include <string.h>
#else
#include <memory.h>
#endif
