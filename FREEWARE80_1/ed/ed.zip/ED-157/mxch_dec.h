/* Included in: cqsort */
extern Int largest;
