#include "BinTree.h"
#include <iostream>
void static __dummy_ (EZPtr<BinTreeNode > &p1)
{
    EZDelete(p1);
}