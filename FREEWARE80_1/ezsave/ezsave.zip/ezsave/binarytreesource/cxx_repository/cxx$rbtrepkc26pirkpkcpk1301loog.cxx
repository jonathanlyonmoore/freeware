#include "BinTree.h"
#include <iostream>
typedef rb_tree<const char *, pair<const char *const , const EZToolsBase * >, select1st<pair<const char *const , const EZToolsBase * >, const char * >, CompareClassNames, allocator<const EZToolsBase * > > __dummy_;