#include "BinTree.h"
#include <iostream>
typedef rb_tree<void *, pair<void *const , void * >, select1st<pair<void *const , void * >, void * >, CompareOIDs, allocator<void * > > __dummy_;