#include "BinTree.h"
#include <iostream>
void static __dummy_ (EZPtr<BinTree > &p1)
{
    EZDelete(p1);
}