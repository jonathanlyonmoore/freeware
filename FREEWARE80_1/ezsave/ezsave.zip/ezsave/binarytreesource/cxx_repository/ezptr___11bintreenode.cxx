#include "BinTree.h"
#include <iostream>
typedef EZPtr<BinTreeNode > __dummy_;