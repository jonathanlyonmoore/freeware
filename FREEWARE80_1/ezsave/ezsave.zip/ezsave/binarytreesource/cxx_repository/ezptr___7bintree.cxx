#include "BinTree.h"
#include <iostream>
#include <time.h>
typedef EZPtr<BinTree > __dummy_;