#include "EZSave.h"
#include <fstream>
typedef rb_tree<void *, pair<void *const , const char * >, select1st<pair<void *const , const char * >, void * >, CompareOIDs, allocator<const char * > > __dummy_;