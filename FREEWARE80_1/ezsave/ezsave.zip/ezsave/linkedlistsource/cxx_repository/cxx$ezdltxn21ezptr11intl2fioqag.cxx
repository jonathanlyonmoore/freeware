#include <iostream>
#include "List.h"
void static __dummy_ (EZPtr<IntListNode > &p1)
{
    EZDelete(p1);
}