#include <iostream>
#include "List.h"
void static __dummy_ (EZPtr<IntList > &p1)
{
    EZDelete(p1);
}