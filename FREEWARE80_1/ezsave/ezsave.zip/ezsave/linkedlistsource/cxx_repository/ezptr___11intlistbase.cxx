#include "List.h"
#include <time.h>
typedef EZPtr<IntListBase > __dummy_;