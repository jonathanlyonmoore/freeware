#include <iostream>
#include "List.h"
typedef EZPtr<IntListNode > __dummy_;