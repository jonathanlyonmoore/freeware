#undef __STDC__
#include <sys/stat.h>
#define __STDC__ 1
