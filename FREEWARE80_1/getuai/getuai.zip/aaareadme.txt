GETUAI

Introduction:

	GETUAI is a utility that allows the user to obtain OpenVMS User
	Authorization Information, from the SYS$SYSTEM:SYSUAF.DAT file, and
	place the information into a DCL symbol.

Function:

	The function of this program is to fetch User Authorization Information
	using the $GETUAI system service in lieu of an F$GETUAI lexical
	function.
 
	Definition and Calling Procedure:
 
		$ GETUAI :== $FERMI$EXE:GETUAI
		$ GETUAI  username /qualifier...
	or
		$ GETUAI  . /qualifier...
 
	Since GETUAI uses the $GETUAI system service, it should work across VMS
	upgrades unlike GETUAF which reads and interprets the UAF records
	directly.

Privileges:

	BYPASS or SYSPRV allows access to any record in the User Authorization
	File (UAF).
 
	GRPPRV allows access to any record in the UAF whose UIC group number
	matches that of the requestor.
 
	Any user can access any UAF record whose UIC matches his own.
 
Building GETUAI:

	Execute the TO_BUILD.COM DCL Procedure.

Author Information:

	The original author of this software is Frank J. Nagy of Fermilab 
	Accelerator Controls. 

Submittor Information:

	This software was suvmitted to ftp.spc.edu by Nick Metrowsky of
	Rice University; Houston, Texas.
