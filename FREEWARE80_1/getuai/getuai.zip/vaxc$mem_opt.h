 
/* VAXC$MEM_OPT
 Defines macros to redefine memory allocation routines to use the
 VMS V5.0 VAXC$xxxx_OPT entry points.  These entry points take advantage
 of the VMS RTL memory management routines LIB$GET_VM and LIB$FREE_VM
 for better performance and AST reentrancy.
 
 Created for VMS V5.1 on 19-Apr-1989 (FJN)
*/
 
#ifndef VAXC$MEM_OPT
#define VAXC$MEM_OPT    1       /* To invoke this procedure only once! */
 
#define malloc  VAXC$MALLOC_OPT
#define calloc  VAXC$CALLOC_OPT
#define free    VAXC$FREE_OPT
#define cfree   VAXC$CFREE_OPT
#define realloc VAXC$REALLOC_OPT
 
#endif
 
