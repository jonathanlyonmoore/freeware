GRAB - a VMS search utility

Copyright (C) 2002 Graham Burley

Intoduction

 GRAB is a search utility for VMS, the main features of interest are:

  o Search using wildcard search srings (* and %) using /WILDCARD
  o Extract windows or sections by search strings using /CUT=(s1[,s2])
  o Incremental processing using /CONTEXT and /LIMIT
  o Scripting support using /SAVE to save information in DCL symbols

 See the help file for documentation and examples.

 The following example procedures are included:

   GRAB_SPLIT.COM   - split file P1 into chunks of P2 records
   GRAB_SUMMARY.COM - search file(s) P1 for string(s) P2 and display summary


Building

 GRAB should compile cleanly on VAX or Alpha using VAXC or DECC, if
 this is not the case please let me know.

  $ @BUILD


Installing / Using

 GRAB can be installed as a foreign command or copied to DCL$PATH. The
 USE.COM procedure can be used to set up symbols for the foreign command
 and to access the help library.

  $ @USE


Contacting the Author

 GRAB was written by Graham Burley. Comments, suggestions and problem
 reports can be sent to the e-mail address:

  burley@encompasserve.com


License

 This software is covered by the GNU General Public License, see the
 file LICENSE.TXT for details.


