/*
 * Define prototypes for exported/imported functions in authlib.c.
 */
int auth_server ( int argc, char **argv, char *log_line, int code_count, ... );

long *auth_getuai_context();

int auth_basic_authorization ( char *astring,
	char *user, int ulen, char *password, int plen, int upcase );

int auth_digest_authorization ( char *astring, char *uri, char *fields[8],
	char *field_store );

typedef int auth_callback ( int local_port, int remote_port, 
	unsigned char *remote_address, char *method, char *setup_file,
	char *ident, char *authorization, char **response, char **log );

