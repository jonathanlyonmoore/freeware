/*
 * define codes for mailbox messages.
 */
#include <msgdef.h>
union netmbx_req_message_s {
    struct {
        short type;			/* message type */
        unsigned short unit;
        long pid;
	char info[248];
    } gen;			/* generic message (common header */

    struct {
	short type;		/* MSG$_DELPROC */
	short unused;
	long finalsts;
	long pid;
	long termtime[2];
	char account[8];
	char username[12];
	long cputim, pageflts, pgflpeak, wspeak, biocnt, diocnt,volumes;
	long login[2], owner;
    } delproc;

    struct {
	short type;		/* MSG$_CONNECT */
    } connect;

    struct {			/* MSG$_NODEACC */
	short type;
    } hello;
};
typedef union netmbx_req_message_s netmbx_req_message;
