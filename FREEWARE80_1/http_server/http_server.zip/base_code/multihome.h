/*
 * The mulithome module handles localaddress-specific information for
 * each actual or virtual interface.
 */
int http_multihomed;			/* global flag, true if multihoming */
int http_cname_count;			/* true if CNAME-based multihoming */

int http_init_multihome();
void http_define_multihome ( char *host, int hlen, char *dot_address );
int http_set_multihome_accesslog ( int ndx );
int http_cname_address ( char *host, unsigned int *address );
int http_multihomed_hostname ( unsigned int address, access_info acc,
	int *accesslog );
int http_multihome_scan ( int ndx, 	/* position in list, 0..n-1 */
	char **name,			/* Returns hostname */
	unsigned char **address );	/* IP address */
