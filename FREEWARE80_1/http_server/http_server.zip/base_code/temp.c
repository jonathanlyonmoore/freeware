#include <builtins.h>
int __STRLEN ( const char *x);
int strlen ( const char *x);
int test ( char *object )
{
    return __STRLEN ( object );
}
