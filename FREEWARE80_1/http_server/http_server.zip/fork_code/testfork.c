/* child progrm for fork test 
 * revised: 9-JUL-1996
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef VMS
#include <unixlib.h>
#else
char **environ;
#endif
int main(int argc, char **argv )
{
    int i, j, content_length; char *cp, line[512];
    char **envp;
    printf ( "Content-type: text/plain\n\n" );
    printf( "arg count to child is %d\n", argc );
    for ( i = 0; i < argc; i++ ) printf("argv[%d] = '%s'\n", i, argv[i]);
    cp = (char *) 0;
    envp = environ;
    printf("environment pointer: %d\n", envp );
    while ( *envp ) {
	if ( strncmp ( *envp, "CONTENT_LENGTH=", 15 ) == 0 ) cp = *envp + 15;
	printf("  %s\n", *envp ); envp++;
    }
    printf("---\n");

    if ( !cp ) cp = getenv ( "CONTENT_LENGTH" );
    content_length = cp ? atoi(cp) : 0;
    if ( content_length > 0 ) {
#ifdef VMS
	/* VMS execv can't handle sys$input right, open CGI_CONTENT_FILE */
	stdin = freopen ( "CGI_CONTENT_FILE", "r", stdin );
#endif
	printf("  content_length is %d, stdin is: %x\n", content_length, stdin );
	for ( i = 0; i < content_length; i += j ) {
	    j = fread ( line, 1, sizeof(line)-1, stdin );
	    if ( j <= 0 ) break;
	    line[j] = '\0';
	    printf("%s", line );
	}
	printf("\n---\n");
    }
    return 1;
}
