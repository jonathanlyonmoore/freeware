import java.lang.*;
import java.util.*;
import java.io.*;
import WWWJexec.*;

public abstract class CGIenv {
   public int flag;
   public WWWJexec logical_link;

   public int write(String str) {
	return this.logical_link.write ( str );
   }

   public static abstract void CGIrun(WWWJexec link) throws IOException;

   public static void WWWrun ( WWWJexec root ) throws IOException {
     root.write("<DNETRECMODE>");		// place in cgi mode
     root.write("<DNETCGI>");		// place in cgi mode
     env.CGIrun(root);			// Invoke the run.
     root.write ( "</DNETCGI>" );
     root.close();
  }
}
