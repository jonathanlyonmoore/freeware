//  Crude test class for CGI shell class.  Place class file in [jbin.cgi]
//  directory.  The shell class sets up the CGI environemt and calls
//  method WWWCGI(), which we override in this subclass.  The scriptserver
//  expects a CGI-style response, which we send.
//  Dump the CGI variables.
//
import java.util.*;
import java.net.*;
import java.io.*;

public class echo extends CGI
{
    public void WWWCGI() {
	write ( "Content-type: text/html\n\n" );
        writeln ( "<HTML><HEAD><TITLE>Java CGI environment echo</TITLE></HEAD><BODY>" );
	writeln ( "<H1>CGI variables </H1>" );
	Enumeration table = this.var.keys();
        while ( table.hasMoreElements() ) try {
	    String key = (String) table.nextElement();
	    writeln ( key + " = '" + this.var.get(key) + "'<BR>" );
        } catch ( NoSuchElementException e ) {
        }
	writeln ( "<HR></BODY></HTML>" );
    }
}
