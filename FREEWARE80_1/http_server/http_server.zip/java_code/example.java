import java.util.*;
import java.net.*;
import java.io.*;

import WWWJexec.*;

public class example
{
	public static void WWWrun ( WWWJexec link ) throws IOException {
	    link.putLog(0,"Made it to log");
	    link.putLog(0,"URL path:"+link.url_path);
	    link.write ( "<DNETPATH>" );
	    String sspath = link.query("<DNETPATH>");
	    try {
	       sspath = link.read();
	    } catch ( IOException e ) {
		System.out.println ( "input fail: " + e );
		return;
	    }
	    link.write("<DNETTEXT>");
	    link.write("200 first success");
	    Date now = new Date();
	    link.write(
		"This program does nothing but indicate the current time: " +
			now );
	    link.write("dnetpath: "+sspath);
	    link.write("</DNETTEXT>");
	    link.close();
	}
}
