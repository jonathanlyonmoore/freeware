import java.util.*;
import java.net.*;
import java.io.*;

import CGIenv.*;

public class example2
{
	public static void WWWrun ( WWWJexec link ) throws IOException {
	    CGIenv cgi = new CGIenv(link);
	    link.putLog(0,"Made it to log");
	    cgi.write("Content-type: text/plain");
	    cgi.write("");
	    Date now = new Date();
	    cgi.write(
		"This program does nothing but indicate the current time: " +
			now );
	    cgi.write("</DNETCGI>");
	    link.close();
	}
}
