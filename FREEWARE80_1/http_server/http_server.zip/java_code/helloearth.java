//  Crude test class for CGI shell class.  Place class file in [jbin.cgi]
//  directory.  The shell class sets up the CGI environemt and calls
//  method WWWCGI(), which we override in this subclass.  The scriptserver
//  expects a CGI-style response, which we send.
//
import java.util.*;
import java.net.*;
import java.io.*;

public class HelloEarth extends CGI
{
    public void WWWCGI() {
	write ( "Content-type: text/html\n\n" );
        writeln ( "<HTML><HEAD><TITLE>Hello Earth</TITL></HEAD><BODY>" );
	write ( "<H1>Now we are cooking with gas</H1>\n" );
	writeln ( "<HR></HTML>" );
    }
}
