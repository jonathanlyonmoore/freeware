import java.util.*;
import java.net.*;
import java.io.*;

import WWWJexec.*;

public class HelloWorld
{
	public static void WWWrun ( WWWJexec link ) throws IOException {
	    link.putLog(0,"Made it to log");
	    link.putLog(0,"URL path:"+link.url_path);
	    link.write ( "<DNETPATH>" );
	    String sspath = "";
	    try {
	       sspath = link.read();
	    } catch ( IOException e ) {
		System.out.println ( "input fail: " + e );
		return;
	    }
	    link.write("<DNETTEXT>");
	    link.write("200 first success");
	    link.write("nutshell\nsmith\none more line.");
	    link.write ( sspath );
	    link.write("</DNETTEXT>");
	    link.close();
	}

	public static void main(String argv[]) throws MalformedURLException, java.io.IOException
	{
		int count=0;
		Date now = new Date();
		System.out.println( "Hello, World.");
		System.out.println( "Now is " + now.toString()  + " (" + now.getTime()  + ")");
	 	if ( argv.length > 1 ) {
		    System.out.println ( "regionmatch result: " +
			argv[0].regionMatches(0,argv[1],0,5) );
		    System.out.println ( "indexOf test: " +
			argv[0].indexOf('/',3) );
		}
		for ( int i=0; i < 100000; i++ ) count = count + 1;
		Date then = new Date();
		long msec = then.getTime() - now.getTime();
		System.out.println( "Iterations: " + count + " (" + msec + " milliseconds)" );
		
	}
}
