int bkg_convert_figure_to_gif ( 
	long hdr[10], 			/* Section header figure subrec */
	unsigned char *data, int datalen,   /* data read from section */
	int (*output)(void*, int, char *), /* User-supplied output function */
	void *outarg );			/* user-arg for output function */
