// Simple test program to test operation of cgienv class.

#include <iostream.hxx>
#include <unixlib.h>

#include "scriptlink.hxx"

#include "cgienv.hxx"

class env_table {
    public:
	char *operator [](char *name);
    private:
	int dummy;
};

char *env_table::operator[](char *name)
{
    char *result = getenv(name);
    return result;
}
int main ( int argc, char ** argv )
{
    int status, plen;
    char *ep, path[256];
  cout << "Hello world\n";

    env_table e;
    ep = e["SYS$LOGIN"];
    status = ScriptLink.write ( "<DNETPATH>", 10 );
    status = ScriptLink.read ( path, 255, plen );
    path[plen] = '\0';
    cout << "Path read status: " << status << ", plen: " << plen << "\n";

    status = ScriptLink.write ( "<DNETTEXT>", 10 );
    ScriptLink.set_rundown ( "</DNETTEXT>" );
    cout << "first write status: " << status;
    if ( (status&1) == 0 ) return status;
    status = ScriptLink.write ( "200 C++ script 12", 17 );
    status = ScriptLink.write ( "Proof this thing works", 22 );
    ScriptLink << "Buffered output possible: " << path << "\n";
    ScriptLink << "sys$login: " << (ep ? ep : "") << "\n";
  cout << "Final write status: " << status;
  return 0;
}
