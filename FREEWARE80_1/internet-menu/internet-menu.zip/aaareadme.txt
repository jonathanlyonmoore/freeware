
    A question I get asked very often is, "What is the Internet and what
    tools do you use to access all the information that's out there ?". 
    Well, this is a sort of question whose answer cannot be distilled into
    a simple answer.   The largest problem people face when first using the
    Internet is grasping all that's available.  Even seasoned users find
    themselves find themselves surprised when they discover a new service
    or feature that they'd never known even existed.  That is one of the
    reason I wrote the INTERNET MENU.  


What is the INTERNET MENU?
--------------------------

    INTERNET MENU is a menu program that is basically a front-end menu to
    the Internet.  This menu is supposed to provide a user with limited
    knowledge of VMS or the Internet the ability to use the resources of
    the Internet.  I feel this menu will also be very useful to even the
    expert Internet travelers.  To access this menu, add this line in your
    login.com or system login.com file.

         $ INT*ERNET :== @USER$DISK:[USER]INTERNET.COM

    where USER$DISK:[USER] is the disk and directory where INTERNET.COM
    resides.  If you're not sure of your disk or directory, simply execute
    the file SETUP.COM ($ @SETUP).  SETUP will find out your current
    directory and disk information and use that information to define
    INT*ERNET as a local symbol. To access the menu, type in INT or
    INTERNET as your DCL '$' prompt

         $ INTERNET <return>

    This will start the executution of INTERNET.COM.  The first thing you
    will see will be the introductory credit screen.  Hit RETURN at that
    point to get to the main menu.  Once you're placed in the main menu,
    you will have 12 differerent options in front of you.  To access any of
    the sub-menu's, pick the number or letter corresponding to your option
    and enter it at the prompt followd by hitting the RETURN key.  Since
    DCL is self- documenting (no, really :-) ), I am not going to go into
    any more details about the inner working of the program at this point. 


    I feel that the easier we make access to information, the  more the
    user will get out of it, which is ultimately better for everyone.  I
    love this menu as it's like your own gopher.  You can customize the
    menu to suit your needs and interests.   I have spent a lot of evenings
    and weekends working on this and would appreciate any comments.  My
    e-mail address is

		carpenterv@vms.csd.mu.edu


                          WHAT'S NEW IN VERSION 4.1
                          -------------------------

o   Fixed a bug in the declaration of the symbol CLEAR.  I had CL, CLS
    and CLEAR defined, but that got a little annoying and so I replaced all
    of those symbols with CLS

o   Added a description of FREENETs in the freenet menu.  I got a lot of
    questions about the purpose and the philosophy behind the freenets.

o   Added support for non-american date format.  The american date format
    is MONTH-DATE-YEAR while the rest of the world uses DATE-MONTH-YEAR. 
    I've definined a symbol with that date format and you only need to
    uncomment it out and comment out the American date format. I hope this
    makes Luke in Austrilia happy.

o   The menu used a few different sites for NETFIND, ARCHIE and WHOIS.  The
    sites I use are big and can usually handle the load, but I'm also
    enclosing a complete list of NETFIND, ARCHIE and WHOIS sites and so you
    can pick a site that closer to you for a better reponse.  You will have
    to make the changes in the menu. 

o   Changed the definitation of the Internet.  Option 1 was 'What is the
    Internet?' and the definiation didn't really convey the message.  I
    hope the new defination is a little better.

o   A few of the symbols were defined in the following format: x:==y.  I
    changed that so that the local definition does not affect predefined or
    global symbol.  DCL Equiv: SET SYMBOL/SCOPE=(NOLOCAL,NOGLOBAL)

o   I had made a little typo in the address of the Cleveland freenet.  The
    address was FREENET-IN-A.CWRU.EDU, but I had a '-' after the A.  Thanks
    Joe Kmoch.

o   Removed all UCXism like rlogin to make the menu completely portable
    with all different TCP/IP packages.  UCX comes with RLOGIN that allows
    the user to pass the username as a parameter.

o   Added a terminal locking program to make the menu a complete shell. 
    Ideally, a user would not have to leave the menu at all.  With the
    addition of termlock and mail, I feel that this program would be a 
    complete shell for anyone getting with the VAX.

                               CHEESY GRAPHIC:
                               --------------

	  ###   #     # ####### ####### ######  #     # ####### #######
	   #    ##    #    #    #       #     # ##    # #          #
	   #    # #   #    #    #       #     # # #   # #          #
	   #    #  #  #    #    #####   ######  #  #  # #####      #
	   #    #   # #    #    #       #   #   #   # # #          #
	   #    #    ##    #    #       #    #  #    ## #          #
	  ###   #     #    #    ####### #     # #     # #######    #


        	        #     # ####### #     # #     #
                	##   ## #       ##    # #     #
	                # # # # #       # #   # #     #
        	        #  #  # #####   #  #  # #     #
                	#     # #       #   # # #     #
	                #     # #       #    ## #     #
        	        #     # ####### #     #  #####


                                FUTURE PLANS:
                               --------------

    There are a lot of things I would like added or changed in the menu.
    This is only a partial list. 

    - Real help library
    - Create a setup file for each user that would store his/her personal
      preferences. eg: printer queue, personal name etc
    - Add an option that would allow the user to selectively add or remove
      items from the menu.  
    - Creation of a hot-list that would store items that are used most
      often.
    - Port this whole puppy to perl that would allow users on UNIX boxes
      access to the menu.
    - Convince people that DCL is really a programming language.


---

    Vinit S. Carpenter				Marquette University
    Telephone/Voice Mail: (414) 288-3750	Computer Services Division
    FAX Number: (414) 288-3300			1313 W. Wisconsin Ave, Rm 240D
    Internet: carpenterv@vms.csd.mu.edu		Milwaukee, WI 53233 USA
------------------------------------------------------------------------------
         Author of INTERNET-MENU for OpenVMS: E-mail me for details
------------------------------------------------------------------------------
