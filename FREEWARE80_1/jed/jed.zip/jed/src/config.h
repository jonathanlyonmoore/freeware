#ifndef _JED_CONFIG_H_
#define _JED_CONFIG_H_
/*
 *  Copyright (c) 1993, 1994 John E. Davis  (davis@amy.tch.harvard.edu)
 *  All Rights Reserved.
 */
#ifdef msdos
# define pc_system
#else
# if defined (__GO32__) || defined (__os2__)
#  define pc_system
# endif
#endif

#ifdef __cplusplus
#define EXTERN extern "C"
#else
#define EXTERN extern
#endif

#if defined(_MSC_VER) || defined(__EMX__)
#define strcmpi stricmp
#define strncmpi strnicmp
#endif

#ifndef HAS_MOUSE
#if !defined(pc_system) 
#if !defined(__alpha) || defined(__osf__)
#define HAS_MOUSE
#endif
#endif
#endif

#define LONG long

/* #define USE_EFENCE */

#ifdef USE_EFENCE
extern char *Xstrcpy(char *, char *);
extern int Xstrcmp(char *a, char *b);
extern char *Xstrncpy(char *, char *, int);
#undef HAS_MEMCPY
#undef HAS_MEMCMP
#undef HAS_MEMSET
#define strcpy Xstrcpy
#define strcmp Xstrcmp
#define strncpy Xstrncpy
#endif


#endif
