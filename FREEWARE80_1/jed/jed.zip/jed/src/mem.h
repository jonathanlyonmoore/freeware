/*
 *  Copyright (c) 1992, 1994 John E. Davis  (davis@amy.tch.harvard.edu)
 *  All Rights Reserved.
 */

/* If your compiler does not have memory.h, ignore this line */
#ifndef VMS
#include <memory.h>
#endif 


#ifdef HAS_MEMSET
#define MEMSET memset
#else 
#define MEMSET jed_memset
extern void jed_memset(char *, char, int);
#endif

#ifdef HAS_MEMCHR
#define MEMCHR memchr
#else 
#define MEMCHR jed_memchr
extern char *jed_memchr(register char *, register char, register int);
#endif

#ifdef HAS_MEMCPY
#define MEMCPY memcpy
#else
#define MEMCPY jed_memcpy
extern char *jed_memcpy(char *, char *, int);
#endif

#ifdef HAS_MEMCMP
#define MEMCMP memcmp
#else
#define MEMCMP jed_memcmp
extern int jed_memcmp(char *, char *, int);
#endif

