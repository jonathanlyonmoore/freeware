/*
 *  Copyright (c) 1992, 1994 John E. Davis  (davis@amy.tch.harvard.edu)
 *  All Rights Reserved.
 */
extern void vscroll_down(int, int, int);
extern void vscroll_up(int, int, int);
extern void execute_vscroll_down(int, int, int);
extern void execute_vscroll_up(int, int, int);
extern void vins(char);
extern void vdel(void);
extern void vdel_eol(void);
