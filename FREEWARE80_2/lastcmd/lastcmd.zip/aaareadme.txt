LASTCMD - Grab and Display Last Terminal Command
(c) Copyright 1994, Chris Olive and Siemens Medical Systems
------------------------------------------------------------------------------

LASTCMD allows a suitably privileged  user  (one  with  CMKRNL)  peek  at  the
typeahead  buffer of another terminal.  This allows one to grab another's last
command no matter in what environment the target user may be.  As long as  the
environment   utilizes   the   terminal's   typeahead   buffer   (usually  via
LIB$GETINPUT), LASTCMD will display that command.  Utilities using SMG do  not
use  the  typeahead  buffer  and  there are a few other exceptions.  (In these
cases, LASTCMD will still report the last command  in  the  typeahead  buffer;
that  command  just  may  not be the very, very thing the user is doing at the
moment).  But overall, LASTCMD will grab the last  command  typed  by  another
user  and display it.  Use LASTCMD in place of Hunter Goatley's GETCMD utility
when the target user is not in the DCL environment at the moment.

Syntax:  LASTCMD <terminal-name>

Unfortunately, LASTCMD will not support RT devices  since  the  internal  data
structure LASTCMD uses (UCB -> TTYTA) is not inherit with the RT device.

LASTCMD utilitizes kernel mode code, so maintain the caution one should always
maintain  when  using CMKRNL utilities.  It has been tested and is believed to
work okay.  However, neither I  nor  my  employer  can  be  or  will  be  held
responsible  for  any  damages which result from the use or misuse of LASTCMD.
Use of LASTCMD implies that you understand all that.  Other  than  that,  have
fun!

_______________________________________________________________________________
    ___  ___  ___ _   _  ___ _  _  ___                                         
   /___   |  |__  |\ /| |__  |\ | /___    Chris Olive, VMS Systems Consultant   
   ___/  _|_ |___ | Y | |___ | \| ___/       Internet: olive@sgi.siemens.com   
           Medical Systems, Inc.                Voice: 708.304.7793            
         2501 N. Barrington Road.                 FAX: 708.304.7704            
        Hoffman Estates, IL  60195         CompuServe: 73740,1636              
_______________________________________________________________________________
