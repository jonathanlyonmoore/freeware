Directory deletion program.

Requirements
-------------
 The  loop  help  is  generated  using TEXT2C, but in principle (and
 unless you modify it) it is already generated.  TEXT2C is available at
	http://nucwww.chem.sunysb.edu/htbin/software_list.cgi

 This software requires either MMK or MMS for compilation.
        MMS is � Digital Equipment Corporation, All right reserved.
        MMK is � MadGoat Software.  All Rights Reserved.
                                                           
Platform
--------
 It  has  been  tested  on  VAX OpenVMS 6.1 and Alpha OpenVMS 6.2 using
 respectively VAXC V3.2-044 and DECC V6.0-001.

 I  have  also  compiled and tested this package using GCC 2.8.0 on AXP
 but the  messaging  utility  was  behaving  chaotically  (i.e.   shows
 messages  but  not  related  to  what  is  declared in .MSG).  For the
 moment, we include a GCC hack and prints messages to std-error instead
 of  using  VMS  message facility __BUT__ If someone figures out out to
 get it to work properly with GCC, I'll be delighted to know about it.

 *** GCC VAX UN-SUPPORTED due to rather poor support and implementation.
 You may try it and succeed (and I'd be glad to know about it).


 This software is still under development.

Compilation
-----------
Apart of that :
	$ MMK				on VAX or Alpha
	or
	$ MMS				on VAX
	$ MMS/MACRO=(__AXP__=1)		on Alpha

GCC is enabled with /MACRO=(GNUC=1).


Installation
------------
 You can either
 - Define a global symbol LOOP :== $dev:[dir]LOOP
 - Place the executable in DCL$PATH (VMS 6.2 and up)
 - Insert the following in DCLTABLES
	define verb LOOP
		image dev:[dir]LOOP
		cliflags(foreign)


 Remember  to  also  install  the help file where it should be.  If you
 don't want to, help is available on-line at
	http://nucwww.chem.sunysb.edu/helplib/@hvmsapps/LOOP


Author
------
 J�r�me LAURET ; jlauret@mail.chem.sunysb.edu



History
-------
 17-Jul-1999	Added GCC support.
 27-Jul-1999	Added /QUIT + $find_file() returns the file with version number
		; this does not fit our initial intent (LOOP/ONFILE=*.TXT PURGE)
		for example would fail. Fixed.

