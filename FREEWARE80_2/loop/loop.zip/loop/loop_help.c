  /* Formatted by text2c V1.1 (Flex V2.5). Last update 11-May-1999 */
  printf("\n LOOP  is  a  DCL command repetition program.\n\n Usage : ");
  printf("LOOP[/qualifier] [command {+ command ...}]\n\n General quali");
  printf("fiers\n  /CLEAR\tClear the screen at each loop.\n  /LOGCNT\t");
  printf("Display the time and log count.\n  /EVERY{=s}\trepeat every ");
  printf("'s' seconds.  Default is 30 seconds.\n  /MAX{=n}\texecute th");
  printf("e list of command 'n' times. Default is to execute\n\t\tthe ");
  printf("commands infinitly.\n  /QUIT\t\tQuit after first execution.\n");
  printf("\n Repeat Command(s) Mode\n  /REPEAT\tCommand mode (default)");
  printf("\n\n Command(s) executed over selected file Mode\n  /ONFILE=");
  printf("List\tSelect a list of files.\n  /DIRECTORY\tProcess directo");
  printf("ries as well.\n  /LEAVE\tLeave LOOP if no files were selecte");
  printf("d.\n\n");