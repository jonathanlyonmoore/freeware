
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *
 *
 *
 *                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\
 *                %% \___________________________________%% \
 *                %% |                                   %%  \
 *                %% |               DORMANT             %%   \
 *                %% |           dormant.c  c2004        %%    \
 *                %% |            Lyle W. West           %%    |
 *                %% |                                   %%    |
 *                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    |
 *                \                                        \   |
 *                 \                                        \  |
 *                  \                                        \ |
 *                   \________________________________________\|
 *
 *
 *
 *  Copyright (C) 1998, 2004 Lyle W. West, All Rights Reserved.
 *  Permission is granted to copy and use this program so long as [1] this
 *  copyright notice is preserved, and [2] no financial gain is involved
 *  in copying the program.  This program may not be sold as "shareware"
 *  or "public domain" software without the express, written permission
 *  of the author.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


  DORMANT (V1.3-3)

        DORMANT is a tool to display SYSUAF info about inactive users,
        specifically users which have not logged in, for example,
        in the past 90 days.
        Command qualifiers are present to specify a particular group,
        the idle interval, and interactive and/or noninteractive usage.

     Parameters:

       None

     Qualifiers:

        /GROUP - if present, inactivity info displayed pertains only
                to the specified group of users. The group can be specified
                as a rightslist symbol, such as SUPPORT, or numerically as
                an octal value, 225. (/GROUP=225 or /GROUP=SUPPORT).

        /IDLEDAYS=nn - if present, and a value is entered, the value
                is used as the idle delta time for comparison to the
                login information.
                If omitted, the interval defaults to 90 days.

        /NOOWNER - if present, DORMANT does NOT display the uaf owner
                information. Note that the owner field is also inhibited
                if the /GROUP qualifier is specified

        /NONINTERACTIVE - if present DORMANT also displays the number
                of days since a non-interactive login occurred.
                If omitted, only interactive login information is displayed

        /NOSTATISTICS - if present, DORMANT suppresses the display of node,
                date, column labels and summary information. The default is
                to display this information.

        /OUTPUT=filespec - if present DORMANT output is directed to the
                specified filespec. The default places output to the display.
                A filespec is required with this qualifier

        /USER_FILTER - if present, DORMANT will parse each username
                for an exact match of the filter string. A filter string of
                'MIT' will match usernames 'SMITH' and 'KERMIT'. The filter
                string must be alphanumeric characters, '_' and '$'.
                Any other characters will display an error message and DORMANT
                will exit.
                This qualifier is ignored if /GROUP is also specified.

        /HELP - Displays this text

        /VERSION - if present DORMANT displays version, build date,
                and required privs

%%%%%%%%%%%%

Sample Output:

        Node VAXINE on 11-JUL-2004 23:32:57
        Inactivity Period: 90 days

 Username     Owner                   I    N  Default

 ANONYMOUS    Anonymous FTP           -       DKA100:[ANONYMOUS]
 DEFAULT      Template                -    -  SYS$SYSDEVICE:[USER]
 DUMMY        Dummy, no priv        510  509  DISK$VSUSER:[DUMMY]
 PHASEIV      VPM$SERVER DEFAULT      -       SYS$SPECIFIC:[MOM$SYSTEM]
 SYSTEST      SYSTEST-UETP            -    -  SYS$SYSROOT:[SYSTEST]
 TCPIP$FTP    TCPIP$FTP               -       SYS$SYSDEVICE:[TCPIP$FTP]
 TCPIP$REXEC  TCPIP$REXEC             -    -  SYS$SYSDEVICE:[TCPIP$REXEC]
 TCPIP$RSH    TCPIP$RSH               -    -  SYS$SYSDEVICE:[TCPIP$RSH]
 TCPIP$SMTP   TCPIP$SMTP              -    -  SYS$SPECIFIC:[TCPIP$SMTP]
 TCPIP$XDM    TCPIP$XDM               -  500  SYS$SPECIFIC:[TCPIP$XDM]

        Summary: 10 User records displayed


