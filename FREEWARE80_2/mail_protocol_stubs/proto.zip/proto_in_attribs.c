#include	<stdio.h>			/* standard I/O definitions */
#include	<descrip.h>			/* descriptor definitions */
#include	<ssdef.h>			/* system service definitions */
#include	<varargs.h>			/* variable arguments */

void Dump_TLD(struct dsc$descriptor *t) ;

/*
 *	Read the attributes TLD from the network link
 *
 *	mai$ax_attribs	descriptor in which to return the attributes TLD for
 *			a foreign file format.
 *
 * Return: System status code for success/failure
 *
 */

PROTO_IN_ATTRIBS(
	long	*mai$al_context,		/* Context field for protocol */
	long	mai$l_operation,		/* LNK_C_IN_ATTRIBS */
	va_list	arglist)			/* remainder of arguments */
{
	struct	dsc$descriptor	*mai$ax_attribs ; /* Returned attributes TLD */

	mai$ax_attribs =
	  (struct dsc$descriptor *) va_arg(arglist, struct dsc$descriptor *) ;

	printf( "* Operation type = %d (LNK_C_IN_ATTRIBS)\n", mai$l_operation );
	printf( "  Context field  = 0x%08x\n", *mai$al_context );

	Dump_TLD( mai$ax_attribs ) ;		/* Dump the formatted TLD */

	return(SS$_NORMAL) ;			/* Return success to caller */
}
