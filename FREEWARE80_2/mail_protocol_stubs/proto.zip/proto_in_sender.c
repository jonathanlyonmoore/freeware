#include	<stdio.h>			/* standard I/O definitions */
#include	<descrip.h>			/* descriptor definitions */
#include	<ssdef.h>			/* system service definitions */
#include	<varargs.h>			/* variable arguments */

/*
 *	Read the sender name from the network link
 *
 *	mai$ax_sender		descriptor to write to for sender name,
 *				generally in form:
 *					'ATGQ50::NICK		"Nick de Smith"'
 *
 * Return: System status code for success/failure
 *
 */

PROTO_IN_SENDER(
	long	*mai$al_context,		/* Context field for protocol */
	long	mai$l_operation,		/* LNK_C_IN_SENDER */
	va_list	arglist)			/* remainder of arguments */
{
	struct	dsc$descriptor	*mai$ax_sender ;/* Returned sender name */

	mai$ax_sender =
	  (struct dsc$descriptor *) va_arg(arglist, struct dsc$descriptor *) ;

#ifdef Compile_Error
In this statement, the identifier "printf" is implicitly declared as a function.
#endif
	printf( "* Operation type = %d (LNK_C_IN_SENDER)\n", mai$l_operation );
	printf( "  Context field  = 0x%08x\n", *mai$al_context );

	return(SS$_NORMAL) ;			/* Return success to caller */
}
