#include	<stdio.h>			/* standard I/O definitions */
#include	<descrip.h>			/* descriptor definitions */
#include	<ssdef.h>			/* system service definitions */
#include	<varargs.h>			/* variable arguments */

/*
 *	Read a buffer from a network link
 *
 *	mai$ax_buffer		descriptor for buffer to read into
 *
 * Return: System status code for success/failure
 *
 */

PROTO_IO_READ(
	long	*mai$al_context,		/* Context field for protocol */
	long	mai$l_operation,		/* LNK_C_IO_READ */
	va_list	arglist)			/* remainder of arguments */
{
	struct	dsc$descriptor	*mai$ax_buffer ;/* Buffer to read into 	*/

	mai$ax_buffer =
	  (struct dsc$descriptor *) va_arg(arglist, struct dsc$descriptor *) ;

	printf( "* Operation type = %d (LNK_C_IO_READ)\n", mai$l_operation );
	printf( "  Context field  = 0x%08x\n", *mai$al_context );

	return(SS$_NORMAL) ;			/* Return success to caller */
}
