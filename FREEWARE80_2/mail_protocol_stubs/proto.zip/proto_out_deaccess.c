#include	<stdio.h>			/* standard I/O definitions */
#include	<descrip.h>			/* descriptor definitions */
#include	<ssdef.h>			/* system service definitions */

/*
 *	Break a connection (possibly with a remote node)
 *
 * Return: SS$_NORMAL for success, else mai$l_signal as passed
 *
 */

PROTO_OUT_DEACCESS(
	long	*mai$al_context,		/* Context field for protocol */
	long	mai$l_operation	)		/* LNK_C_OUT_DEACCESS */
{
	printf( "* Operation type = %d (LNK_C_OUT_DEACCESS)\n", mai$l_operation );
	printf( "  Context field  = 0x%08x\n", *mai$al_context );

	return(SS$_NORMAL) ;			/* Return success to caller */
}
