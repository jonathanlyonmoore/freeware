int read_key_boolean();
int read_key_text();

struct key {
  char *name;
  int *var;
  int (*readkey)();
};

int spawn,verify,ignore_errors,execute,
		debug,keep,usedefaults,alwaysrebuild,usage_flag;
char *makefilename,*cmd_fname,*targetnamelist;
char *p[9];			/* Only 8, but starting at 1 :-) */
int macrocnt;
char *macrofiles[32];          /* 32 is surely enough... */

#define BOOLEAN_KEY(KEYWORD,KEYVAR) \
		{KEYWORD,KEYVAR,read_key_boolean}
#define TEXT_KEY(KEYWORD,KEYVAR) \
		{KEYWORD,KEYVAR,read_key_text}

#define MAXKEYS 19
struct key keylist[MAXKEYS] = {
  BOOLEAN_KEY("SPAWN",&spawn),
  BOOLEAN_KEY("VERIFY",&verify),
  BOOLEAN_KEY("IGNORE",&ignore_errors),
  BOOLEAN_KEY("EXECUTE",&execute),
  BOOLEAN_KEY("DEBUG",&debug),
  BOOLEAN_KEY("KEEP",&keep),
  BOOLEAN_KEY("DEFAULTS",&usedefaults),
  BOOLEAN_KEY("FORCE",&alwaysrebuild),
  BOOLEAN_KEY("HELP",&usage_flag),
  TEXT_KEY("INPUT",&makefilename),
  TEXT_KEY("OUTPUT",&cmd_fname),
  TEXT_KEY("P1",&p[1]),
  TEXT_KEY("P2",&p[2]),
  TEXT_KEY("P3",&p[3]),
  TEXT_KEY("P4",&p[4]),
  TEXT_KEY("P5",&p[5]),
  TEXT_KEY("P6",&p[6]),
  TEXT_KEY("P7",&p[7]),
  TEXT_KEY("P8",&p[8]),
};
