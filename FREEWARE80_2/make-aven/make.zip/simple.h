#define TRUE 1
#define FALSE 0
#define AND &&
#define NOT !
#define OR ||

#define tfree(x) if(x) free(x),x=NULL

#define Dprintf if(debug)printf

