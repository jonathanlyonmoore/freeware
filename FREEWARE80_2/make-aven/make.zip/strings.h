
#define strdesc		struct dsc$descriptor_s
#define DESCRIP(X,Y)	X.dsc$w_length = strlen(Y), \
			X.dsc$b_dtype = DSC$K_DTYPE_T, \
			X.dsc$b_class = DSC$K_CLASS_S, \
			X.dsc$a_pointer = Y;

#define varstr(MAXLEN)	struct {unsigned short curlen; char body[MAXLEN];}
#define vardesc		struct dsc$descriptor_vsa
#define VDESCRIP(X,Y)	X.dsc$w_maxstrlen = sizeof(Y) - 3, \
			X.dsc$b_dtype = DSC$K_DTYPE_VT, \
			X.dsc$b_class = DSC$K_CLASS_VS, \
			X.dsc$a_pointer = &Y;

#define UPCASE(X,Y)	for(Y=X; *Y!='\0'; Y++) *Y = toupper(*Y);
#define DOWNCASE(X,Y)	for(Y=X; *Y!='\0'; Y++) *Y = tolower(*Y);

#define STRING(X,Y)	X = malloc(strlen(Y)+1), strcpy(X,Y);
