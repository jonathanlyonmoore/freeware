MBOX V1.6 15-MAY-1995 Neill Clift (neill@macro.demon.co.uk)

I have worked on a number of real time systems under VMS and I have always
meant to write a peek into mailbox's program. About a year ago I finally got
round to it. The program knows about mailbox message formats for V5.4 thru
G7.0. It will need changing if/when DEC ever change it in a future release.

To run the program define it as a foreign command:

mbox :== $fullfilespec:mbox.exe

*NOTE*

If you do make any changes, find any bugs or even just have some good ideas
about the program *PLEASE* let me know about them. If you think there are
synchronization problems with the code let me know.

Problems:

In Jul 1994 I said:

   It does not see the first few mailbox's in the system as these are not
   returned by sys$device_scan.

Since then Ian Miller of Softel Systems pointed out to me that the reason for
this was that the hard coded mailboxes had the wrong device type. I modified
the program to use $device_scan based not on device class and type but device
class and device name. The kernel code allows mailboxes with types of either
zero or one. Its a hack really but I consider the bug to be within VMS.

Deassigning a channel to a mailbox seems to cause all processes in RWMBX to
become computable. So in order to see processes in RWMBX the program does an
arbitrary wait after deassigning mailbox channels to full mailboxes. This may
be subject to timing windows

Mailbox messages written by drivers seem to have rubbish PIDs (for example the
mailbox written to JOB_CONTROL (MBA1) by TTDRIVER on unsolicited input to an
unassigned terminal. I have since added code to filter these out based on the
function field of these messages being zero. I am greatfull to Greg Bernard
(gbernard@dbc.com) for providing this info and some good ideas.

I don't like the output format that much but I just don't have the brains to
come up with anything better.

In Jul 1994 I said:

   It all seems to work on the AXP but I am very much less sure that its
   synchronized correctly (I don't have the VMS source CD for the AXP so I
   can't check). /RWMBX does not work as R5 no longer contains the UCB address
   during these waits. There is probably another way of obtaining the info but
   I don't know what it is yet.

I have now seen a DSNLINK article that shows how to do this on the AXP via R2
(the channel). I will need to get access to P1 space of the target but this is
something I might do in the future.

Whats new:

I added details of the table in which the logical name is defined.

MBOX now displays the creator of the mailbox for temporary mailboxes.

I modified the code not to place explicit <CR><LF> pairs in the output file. It
was doing this because I was being lazy and using !/ directives in FAO. In fact
I am still being lazy but I added some code to break the lines before calling
$put.

Have fun.
                                   Neill.
