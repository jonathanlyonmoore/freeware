MLSEARCH V3.1

Modified to compile cleanly on Alpha and to fix a couple of CLI parsing
glitches by Hunter Goatley, October 27, 1997.

To produce an .EXE from the supplied object libraries:

	$ @LINK

To rebuild from sources, use MMK (MadGoat MaKe) or Digital's MMS.

---------------------------Original AAAAREADME.TXT -----------------------------
MLSEARCH is a program for searching mail files/folders for strings. It is
hacked from LIBSEARCH, which is a SEARCH command for help/macro/text libraries.
I wrote this program because, although MAIL already has good qualifiers for
selecting messages based on content/subject/date, etc., it suffers from
some restrictions:

  You can only search one folder at time, so it is difficult to find messages
    if you don't know what folder/file they are in;

  You can combine criteria, but you only have one selection available per
    criteria. Thus, you can find all messages containing "fred" in the subject
    field since 1 apr 1990, but you cannot find all messages containing "fred"
    or "jane" in the subject field.

MLSEARCH allows you to circumvent both these restrictions, and to do
many other things, such as process messages automatically with an
arbitrary command file.

To build MLSEARCH, after unpacking the files into their own directory:

$ @BUILD

Then copy MLSEARCH.EXE to where you keep these things, and set up a
foreign command to point to it, by putting

$ MLSEARCH :== $disk:[dir]MLSEARCH

in SYLOGIN.COM, or some other appropriate place.

It takes about 2.5 minutes CPU to build MLSEARCH on a microvax II.

Modify the help if necessary, (in MLSEARCH.HLP) and add to your help library.

All done!

This version (3.0) of MLSEARCH is hopefully an improvement on the first
version I released in April 1991 (V2.0). It contains a number of bug
fixes and some improvements. However, there are still things that could
be improved, in particular the ineffecient handling of the /REVIEW=@FILE
option and the lack of ability to search sequential mail files. I would
also like to add an option to search messages as a whole rather than as
records (i.e. find all messages containing BUG and MLSEARCH, not necessarily
on the same line.)

I welcome your comments and gripes.

Please report bugs, etc. to K.Ashley@Uk.Ac.Ulcc (Janet).
                            K.Ashley@Ulcc.Ac.Uk (Most of rest of world)
