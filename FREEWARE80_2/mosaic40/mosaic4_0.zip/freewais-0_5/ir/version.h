/* WIDE AREA INFORMATION SERVER SOFTWARE:
   No guarantees or restrictions.  See the readme file for the full standard
   disclaimer.

   5.29.90	Harry Morris, morris@think.com
 *
 * $Log:	version.h,v $
 * Revision 1.2  93/08/27  17:59:49  warnock
 * Changed version number to 0.2
 * 
 * Revision 1.1  1993/02/16  15:05:35  freewais
 * Initial revision
 *
 * Revision 1.8  92/02/29  23:01:13  jonathan
 * next release...
 * 
 */

/* Copyright (c) CNIDR (see ../COPYRIGHT) */


#ifndef VERSION_H
#define VERSION_H

#define VERSION "freeWAIS Release 0.5"

#endif /* ndef VERSION_H */
