/* Functions implemented in ellipsis.c */
int compact_string(char *main_string, char *ellipsis_string, 
		    int num_chars, int mode, int eLength);
