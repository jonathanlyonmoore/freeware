/* <X11/apienvset.h>
 */

#include "decw$include:apienvset.h"
