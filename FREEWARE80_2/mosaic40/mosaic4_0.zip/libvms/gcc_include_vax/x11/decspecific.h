/* <X11/decspecific.h>
 */

#include "decw$include:decspecific.h"

