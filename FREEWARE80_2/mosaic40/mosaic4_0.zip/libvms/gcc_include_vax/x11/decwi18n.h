/* <X11/DECwI18n.h>
 */

#include "decw$include:DECwI18n.h"

