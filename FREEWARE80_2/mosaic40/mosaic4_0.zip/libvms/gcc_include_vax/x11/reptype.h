/* <X11/reptype.h>
 */
#ifndef _X11_REPTYPE_H
#define _X11_REPTYPE_H

#include "decw$include:reptype.h"

#endif	/*_X11_REPTYPE_H*/
