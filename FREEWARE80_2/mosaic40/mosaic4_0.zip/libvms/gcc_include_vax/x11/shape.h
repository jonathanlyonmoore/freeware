/* <X11/shape.h>
 */

#include "decw$include:shape.h"
