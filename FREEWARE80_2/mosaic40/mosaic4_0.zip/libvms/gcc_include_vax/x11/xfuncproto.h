/* <X11/Xfuncproto.h>
 */
#ifndef _X11_XFUNCPROTO_H
#define _X11_XFUNCPROTO_H

#include "decw$include:Xfuncproto.h"

#endif	/*_X11_XFUNCPROTO_H*/
