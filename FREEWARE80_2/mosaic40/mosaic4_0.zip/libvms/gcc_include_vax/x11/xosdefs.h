/* <X11/Xosdefs.h>
 */
#ifndef _X11_XOSDEFS_H
#define _X11_XOSDEFS_H

#include "decw$include:Xosdefs.h"

#endif	/*_X11_XOSDEFS_H*/
