/* <Xm/CutPaste.h>
 */
#ifndef _XM_CUTPASTE_H
#define _XM_CUTPASTE_H

#include "decw$include:cutpaste.h"

#endif	/*_XM_CUTPASTE_H*/
