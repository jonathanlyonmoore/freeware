/* <Xm/RepType.h>
 */
#ifndef _XM_REPTYPE_H
#define _XM_REPTYPE_H

#include "decw$include:reptype.h"

#endif	/*_XM_REPTYPE_H*/
