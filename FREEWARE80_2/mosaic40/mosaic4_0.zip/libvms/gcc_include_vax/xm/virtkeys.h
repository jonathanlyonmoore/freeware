/* <Xm/virtkeys.h>
 */
#ifndef _XM_VIRTKEYS_H
#define _XM_VIRTKEYS_H

#include "decw$include:virtkeys.h"

#endif	/*_XM_VIRTKEYS_H*/
