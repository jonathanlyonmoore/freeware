/* <Xmu/converters.h>
 */
#ifndef _XMU_CONVERTERS_H
#define _XMU_CONVERTERS_H

#include "XMU:converters.h"

#endif	/*_XMU_CONVERTERS_H*/
