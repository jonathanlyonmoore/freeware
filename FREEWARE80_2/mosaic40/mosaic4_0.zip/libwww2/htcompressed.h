#ifndef HTCOMPRESSED_H
#define HTCOMPRESSED_H

extern void HTCompressedFileToFile (char *fnam, int compressed);
extern void HTCompressedHText (HText *text, int compressed, int plain);

#endif /* not HTCOMPRESSED_H */
