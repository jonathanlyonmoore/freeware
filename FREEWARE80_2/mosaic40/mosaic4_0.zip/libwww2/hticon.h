extern char *HTgeticonname(HTFormat format, char *defaultformat);
