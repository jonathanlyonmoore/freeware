/*
                            TELNET AND SIMILAR ACCESS METHODS
 */

#ifndef HTTELNET_H
#define HTTELNET_H

#include "HTAccess.h"

extern HTProtocol HTTelnet;
extern HTProtocol HTRlogin;
extern HTProtocol HTTn3270;

#endif
