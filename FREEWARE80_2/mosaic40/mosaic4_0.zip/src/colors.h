/* This file is Copyright (C) 2005 - The VMS Mosaic Project */

#ifndef __COLORS_H__
#define __COLORS_H__

extern int get_safe_colors(Widget wid);

#endif
