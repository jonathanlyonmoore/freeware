Here are some files modified from Mosaic 2.6 1B OpenVMS source distribution
to build successfully under OpenVMS VAX 5.5-2 with Wollongong Pathway 1.0 

Patrick Moreau - CENA/Athis-Mons - FRANCE
pmoreau@cena.dgac.fr
moreau_p@decus.decus.fr
