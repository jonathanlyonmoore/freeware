#define MALLOC most_malloc
#define REALLOC most_realloc
extern unsigned char *most_malloc(unsigned int);
extern unsigned char *most_realloc(unsigned char *, unsigned int);
extern void exit_error(char *);

extern char SEARCH_STR[80];
extern int SEARCH_DIR;
extern int STARTING_LINE;   /*  begin at this line upon startup of most */
extern int CASE_SENSITIVE;

extern int NUM_LINES;
extern int ACTUAL_LINES;
extern int CURS_ROW;
extern int CURS_COL;
extern unsigned char *CURS_POS;

extern int SQUEEZE_LINES;          /* switch parameters */
extern int MOST_L_OPT;             /* use ^L (formfeed) to clear screen */
extern int MOST_V_OPT;             /* display control chars */
extern int MOST_B_OPT;             /* display Binary File */
extern int MOST_T_OPT;             /* display tab as ^I-- valid only with V option */
extern int MOST_W_OPT;             /* wrap lines if true */
extern int MOST_S_OPT;             /* selective display */
extern int MOST_K_OPT;             /* Kanji option */

extern int MOST_D_OPT;             /* delete file mode  (see ':D')  */

#define _MOST_V_OPT  1
#define _MOST_T_OPT  2
#define _MOST_B_OPT  4
#define _MOST_SQ_OPT 8
#define _MOST_W_OPT 16

