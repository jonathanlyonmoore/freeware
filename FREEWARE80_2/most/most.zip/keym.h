extern void ctrl_x_map_cmd();
extern void ctrl_k_map_cmd();
extern void ctrl_w_map_cmd();
extern void pf1_map_cmd();
extern void pf1_esc_map_cmd();
extern void dec_extended_map_cmd();
extern void esc_map_cmd();
extern void page_down_cmd();
extern void search_cmd();
extern void help_cmd();
extern void next_line_cmd();
extern void previous_line_cmd();
extern void extended_cmd_cmd();
extern void redraw_cmd();
extern void goto_line_cmd();
extern void time_cmd();
extern void page_up_cmd();
extern void page_left_cmd();
extern void page_right_cmd();
extern void sys_spawn_cmd();
extern void set_mark_cmd();
extern void top_of_buffer_cmd();
extern void goto_mark_cmd();
extern void extended_key_cmd();
extern void search_back_cmd();
extern void find_next_cmd();
extern void end_of_buffer_cmd();
extern void exit_cmd();
extern void one_window_cmd();
extern void two_window_cmd();
extern void del_window_cmd();
extern void other_window_cmd();
extern void O_map_cmd();
extern void find_file_cmd();
extern void digit_arg_cmd();
extern void edit_cmd();
extern void toggle_width_cmd();
extern void goto_percent_cmd();
extern void edt_page_cmd();
extern void edt_forward_cmd();
extern void edt_back_cmd();
extern void edt_line_cmd();
extern void edt_find_cmd();
extern void edt_find_next_cmd();

extern int *DIGIT_ARG;

#ifdef VMS
#ifndef isdigit
#define isdigit(x) \
      (((x >= '0') && (x <= '9')) ? 1 : 0)
#endif
#endif

extern int do_extended_key(void);
extern int do_extended_cmd(void);
extern void do_help_command(void);
extern void execute_key(void);

