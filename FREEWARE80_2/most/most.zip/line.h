#ifndef _DAVIS_LINE_H_
#define _DAVIS_LINE_H_
extern int ascii_format_line(char *, char *, int);
extern void expand_tabs(char *, char *);
extern int analyse_line(unsigned char *, unsigned char *, char *, char *);
extern void output(char *, int, char *, char);
extern void display_line();
extern int apparant_distance(unsigned char *);
#endif

