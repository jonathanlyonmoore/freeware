extern int SQUEEZE_LINES;          /* switch parameters */
extern int MOST_A_OPT;             /* automatically choose -b if necessary */
extern int MOST_C_OPT;             /* begin pages at top of screen */
extern int MOST_V_OPT;             /* display control chars */
extern int MOST_B_OPT;             /* display Binary File */
extern int MOST_T_OPT;             /* display tab as ^I-- valid only with V option */
extern int MOST_D_OPT;             /* delete file mode  (see ':D')  */
extern int MOST_L_OPT;             /* use ^L (formfeed) to clear screen */

extern char *MOST_PROGRAM;	   /* Program Name (argv[0]) */
extern void most( char *, int);

