#ifndef _DAVIS_SEARCH_H_
#define _DAVIS_SEARCH_H_
#include <stdio.h>
#include <string.h>

extern int SEARCH_DIR;

extern int search(unsigned char *, int, int *);
extern int substring(char *, char *);
#endif


