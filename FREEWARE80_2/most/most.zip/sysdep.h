#ifndef __DAVIS_SYSDEP_H__
#define __DAVIS_SYSDEP_H__

#include <stdio.h>

#if defined(sequent) || defined(apollo)
# define HAS_TERMIOS 0
#else
# define HAS_TERMIOS 1
#endif

#ifdef VMS
extern unsigned long SHELL_PID;  
extern void define_logical_name (char *, char *);
extern void delete_logical_name (char *);
extern int do_emacs_command(void);

extern int do_shell_command();
extern int expand_file_name(char *,char *);
extern char *unix2vms(char *);

#endif /* VMS */

extern int INPUT_BUFFER_LEN;
extern char INPUT_BUFFER[80];

extern void init_tty(void);
extern int reset_tty(void);
extern char getkey(void);
extern void ungetkey(char);
extern void sys_resume(void);
extern void get_term_dimensions(int *, int *);
extern int sys_delete_file(char *);
extern void set_width(int, int);

extern char *get_time(void);
#endif /* __DAVIS_SYSDEP_H__ */

