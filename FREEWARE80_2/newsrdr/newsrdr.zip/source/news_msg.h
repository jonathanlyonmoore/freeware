/*
 * Generated automatically from news_msg.msg
 */


#ifndef __DECC
#define NEWS__NOCONNECT ((int) news__noconnect)
extern int news__noconnect();
#else  /* __DECC */
globalvalue NEWS__NOCONNECT;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOSERVICE ((int) news__noservice)
extern int news__noservice();
#else  /* __DECC */
globalvalue NEWS__NOSERVICE;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__CFGERR ((int) news__cfgerr)
extern int news__cfgerr();
#else  /* __DECC */
globalvalue NEWS__CFGERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__UNEXPRSP ((int) news__unexprsp)
extern int news__unexprsp();
#else  /* __DECC */
globalvalue NEWS__UNEXPRSP;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__PROTOERR ((int) news__protoerr)
extern int news__protoerr();
#else  /* __DECC */
globalvalue NEWS__PROTOERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NONETADR ((int) news__nonetadr)
extern int news__nonetadr();
#else  /* __DECC */
globalvalue NEWS__NONETADR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__SENDERR ((int) news__senderr)
extern int news__senderr();
#else  /* __DECC */
globalvalue NEWS__SENDERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__RCVERR ((int) news__rcverr)
extern int news__rcverr();
#else  /* __DECC */
globalvalue NEWS__RCVERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__BUFALLOCERR ((int) news__bufallocerr)
extern int news__bufallocerr();
#else  /* __DECC */
globalvalue NEWS__BUFALLOCERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__PAGERR ((int) news__pagerr)
extern int news__pagerr();
#else  /* __DECC */
globalvalue NEWS__PAGERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__COMPOSERR ((int) news__composerr)
extern int news__composerr();
#else  /* __DECC */
globalvalue NEWS__COMPOSERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__KWDSYNTAX ((int) news__kwdsyntax)
extern int news__kwdsyntax();
#else  /* __DECC */
globalvalue NEWS__KWDSYNTAX;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__CMDERR ((int) news__cmderr)
extern int news__cmderr();
#else  /* __DECC */
globalvalue NEWS__CMDERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__CAPTIVE ((int) news__captive)
extern int news__captive();
#else  /* __DECC */
globalvalue NEWS__CAPTIVE;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__ATTERR ((int) news__atterr)
extern int news__atterr();
#else  /* __DECC */
globalvalue NEWS__ATTERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__PRINTERR ((int) news__printerr)
extern int news__printerr();
#else  /* __DECC */
globalvalue NEWS__PRINTERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOPOSTING ((int) news__noposting)
extern int news__noposting();
#else  /* __DECC */
globalvalue NEWS__NOPOSTING;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__POSTERR ((int) news__posterr)
extern int news__posterr();
#else  /* __DECC */
globalvalue NEWS__POSTERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__MAILERR ((int) news__mailerr)
extern int news__mailerr();
#else  /* __DECC */
globalvalue NEWS__MAILERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__REPLYERR ((int) news__replyerr)
extern int news__replyerr();
#else  /* __DECC */
globalvalue NEWS__REPLYERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__SPAWNERR ((int) news__spawnerr)
extern int news__spawnerr();
#else  /* __DECC */
globalvalue NEWS__SPAWNERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOPRINT ((int) news__noprint)
extern int news__noprint();
#else  /* __DECC */
globalvalue NEWS__NOPRINT;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOTYOURS ((int) news__notyours)
extern int news__notyours();
#else  /* __DECC */
globalvalue NEWS__NOTYOURS;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__BODYERR ((int) news__bodyerr)
extern int news__bodyerr();
#else  /* __DECC */
globalvalue NEWS__BODYERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOREPLYADDR ((int) news__noreplyaddr)
extern int news__noreplyaddr();
#else  /* __DECC */
globalvalue NEWS__NOREPLYADDR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__RCRDERR ((int) news__rcrderr)
extern int news__rcrderr();
#else  /* __DECC */
globalvalue NEWS__RCRDERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__RCWRTERR ((int) news__rcwrterr)
extern int news__rcwrterr();
#else  /* __DECC */
globalvalue NEWS__RCWRTERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__LISTREPLYERR ((int) news__listreplyerr)
extern int news__listreplyerr();
#else  /* __DECC */
globalvalue NEWS__LISTREPLYERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__WRITERR ((int) news__writerr)
extern int news__writerr();
#else  /* __DECC */
globalvalue NEWS__WRITERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NONEW ((int) news__nonew)
extern int news__nonew();
#else  /* __DECC */
globalvalue NEWS__NONEW;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOMORE ((int) news__nomore)
extern int news__nomore();
#else  /* __DECC */
globalvalue NEWS__NOMORE;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOMORENEW ((int) news__nomorenew)
extern int news__nomorenew();
#else  /* __DECC */
globalvalue NEWS__NOMORENEW;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOCURART ((int) news__nocurart)
extern int news__nocurart();
#else  /* __DECC */
globalvalue NEWS__NOCURART;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOSUCHGRP ((int) news__nosuchgrp)
extern int news__nosuchgrp();
#else  /* __DECC */
globalvalue NEWS__NOSUCHGRP;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOTSUBSCR ((int) news__notsubscr)
extern int news__notsubscr();
#else  /* __DECC */
globalvalue NEWS__NOTSUBSCR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOCURGROUP ((int) news__nocurgroup)
extern int news__nocurgroup();
#else  /* __DECC */
globalvalue NEWS__NOCURGROUP;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOGRMATCH ((int) news__nogrmatch)
extern int news__nogrmatch();
#else  /* __DECC */
globalvalue NEWS__NOGRMATCH;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__EDNOTFOUND ((int) news__ednotfound)
extern int news__ednotfound();
#else  /* __DECC */
globalvalue NEWS__EDNOTFOUND;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__HDRNOTFOUND ((int) news__hdrnotfound)
extern int news__hdrnotfound();
#else  /* __DECC */
globalvalue NEWS__HDRNOTFOUND;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__INVARTRNG ((int) news__invartrng)
extern int news__invartrng();
#else  /* __DECC */
globalvalue NEWS__INVARTRNG;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__OUTRNG ((int) news__outrng)
extern int news__outrng();
#else  /* __DECC */
globalvalue NEWS__OUTRNG;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__CREATERR ((int) news__createrr)
extern int news__createrr();
#else  /* __DECC */
globalvalue NEWS__CREATERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__EDITERR ((int) news__editerr)
extern int news__editerr();
#else  /* __DECC */
globalvalue NEWS__EDITERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__SUBPERR ((int) news__subperr)
extern int news__subperr();
#else  /* __DECC */
globalvalue NEWS__SUBPERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__OPENERR ((int) news__openerr)
extern int news__openerr();
#else  /* __DECC */
globalvalue NEWS__OPENERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__EXTRERR ((int) news__extrerr)
extern int news__extrerr();
#else  /* __DECC */
globalvalue NEWS__EXTRERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__SIGFERR ((int) news__sigferr)
extern int news__sigferr();
#else  /* __DECC */
globalvalue NEWS__SIGFERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__UPDERR ((int) news__upderr)
extern int news__upderr();
#else  /* __DECC */
globalvalue NEWS__UPDERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__ARTRERR ((int) news__artrerr)
extern int news__artrerr();
#else  /* __DECC */
globalvalue NEWS__ARTRERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOARTSPEC ((int) news__noartspec)
extern int news__noartspec();
#else  /* __DECC */
globalvalue NEWS__NOARTSPEC;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOTHREAD ((int) news__nothread)
extern int news__nothread();
#else  /* __DECC */
globalvalue NEWS__NOTHREAD;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOSUBJECT ((int) news__nosubject)
extern int news__nosubject();
#else  /* __DECC */
globalvalue NEWS__NOSUBJECT;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOMATCH ((int) news__nomatch)
extern int news__nomatch();
#else  /* __DECC */
globalvalue NEWS__NOMATCH;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__KEYDEFERR ((int) news__keydeferr)
extern int news__keydeferr();
#else  /* __DECC */
globalvalue NEWS__KEYDEFERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__SETARCHERR ((int) news__setarcherr)
extern int news__setarcherr();
#else  /* __DECC */
globalvalue NEWS__SETARCHERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__FWDERR ((int) news__fwderr)
extern int news__fwderr();
#else  /* __DECC */
globalvalue NEWS__FWDERR;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__ADDRSYNTX ((int) news__addrsyntx)
extern int news__addrsyntx();
#else  /* __DECC */
globalvalue NEWS__ADDRSYNTX;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOPARENT ((int) news__noparent)
extern int news__noparent();
#else  /* __DECC */
globalvalue NEWS__NOPARENT;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOMOREMATCH ((int) news__nomorematch)
extern int news__nomorematch();
#else  /* __DECC */
globalvalue NEWS__NOMOREMATCH;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOSUBJSPEC ((int) news__nosubjspec)
extern int news__nosubjspec();
#else  /* __DECC */
globalvalue NEWS__NOSUBJSPEC;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOCANCEL ((int) news__nocancel)
extern int news__nocancel();
#else  /* __DECC */
globalvalue NEWS__NOCANCEL;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOIGHDSPEC ((int) news__noighdspec)
extern int news__noighdspec();
#else  /* __DECC */
globalvalue NEWS__NOIGHDSPEC;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOSUCHARTICLE ((int) news__nosucharticle)
extern int news__nosucharticle();
#else  /* __DECC */
globalvalue NEWS__NOSUCHARTICLE;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOMOREGRP ((int) news__nomoregrp)
extern int news__nomoregrp();
#else  /* __DECC */
globalvalue NEWS__NOMOREGRP;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NEWGROUP ((int) news__newgroup)
extern int news__newgroup();
#else  /* __DECC */
globalvalue NEWS__NEWGROUP;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__EOARTICLE ((int) news__eoarticle)
extern int news__eoarticle();
#else  /* __DECC */
globalvalue NEWS__EOARTICLE;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__EOLIST ((int) news__eolist)
extern int news__eolist();
#else  /* __DECC */
globalvalue NEWS__EOLIST;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOTIMPL ((int) news__notimpl)
extern int news__notimpl();
#else  /* __DECC */
globalvalue NEWS__NOTIMPL;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOOPNPROF ((int) news__noopnprof)
extern int news__noopnprof();
#else  /* __DECC */
globalvalue NEWS__NOOPNPROF;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__ALRDYSUB ((int) news__alrdysub)
extern int news__alrdysub();
#else  /* __DECC */
globalvalue NEWS__ALRDYSUB;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__HDRALRDY ((int) news__hdralrdy)
extern int news__hdralrdy();
#else  /* __DECC */
globalvalue NEWS__HDRALRDY;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__EOGROUP ((int) news__eogroup)
extern int news__eogroup();
#else  /* __DECC */
globalvalue NEWS__EOGROUP;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__MUSTMAIL ((int) news__mustmail)
extern int news__mustmail();
#else  /* __DECC */
globalvalue NEWS__MUSTMAIL;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__CONNECTING ((int) news__connecting)
extern int news__connecting();
#else  /* __DECC */
globalvalue NEWS__CONNECTING;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__RECONNECTING ((int) news__reconnecting)
extern int news__reconnecting();
#else  /* __DECC */
globalvalue NEWS__RECONNECTING;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__UPDATING ((int) news__updating)
extern int news__updating();
#else  /* __DECC */
globalvalue NEWS__UPDATING;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__USINGCURGROUP ((int) news__usingcurgroup)
extern int news__usingcurgroup();
#else  /* __DECC */
globalvalue NEWS__USINGCURGROUP;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__ALRDYIGNORE ((int) news__alrdyignore)
extern int news__alrdyignore();
#else  /* __DECC */
globalvalue NEWS__ALRDYIGNORE;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__MARKCOUNT ((int) news__markcount)
extern int news__markcount();
#else  /* __DECC */
globalvalue NEWS__MARKCOUNT;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NEWCOUNT ((int) news__newcount)
extern int news__newcount();
#else  /* __DECC */
globalvalue NEWS__NEWCOUNT;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__CANCELLED ((int) news__cancelled)
extern int news__cancelled();
#else  /* __DECC */
globalvalue NEWS__CANCELLED;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__SUBSCRIBED ((int) news__subscribed)
extern int news__subscribed();
#else  /* __DECC */
globalvalue NEWS__SUBSCRIBED;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__GRPSET ((int) news__grpset)
extern int news__grpset();
#else  /* __DECC */
globalvalue NEWS__GRPSET;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__GRPINFO ((int) news__grpinfo)
extern int news__grpinfo();
#else  /* __DECC */
globalvalue NEWS__GRPINFO;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__EXTRACTED ((int) news__extracted)
extern int news__extracted();
#else  /* __DECC */
globalvalue NEWS__EXTRACTED;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__FOLLOWTHREAD ((int) news__followthread)
extern int news__followthread();
#else  /* __DECC */
globalvalue NEWS__FOLLOWTHREAD;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__NOMORETHREAD ((int) news__nomorethread)
extern int news__nomorethread();
#else  /* __DECC */
globalvalue NEWS__NOMORETHREAD;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__ALLDONE ((int) news__alldone)
extern int news__alldone();
#else  /* __DECC */
globalvalue NEWS__ALLDONE;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__SPAWNED ((int) news__spawned)
extern int news__spawned();
#else  /* __DECC */
globalvalue NEWS__SPAWNED;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__DIDSUB ((int) news__didsub)
extern int news__didsub();
#else  /* __DECC */
globalvalue NEWS__DIDSUB;
#endif /* __DECC */
#ifndef __DECC
#define NEWS__DIDUNSUB ((int) news__didunsub)
extern int news__didunsub();
#else  /* __DECC */
globalvalue NEWS__DIDUNSUB;
#endif /* __DECC */
