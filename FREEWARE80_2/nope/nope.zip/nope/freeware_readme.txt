NOPE,System Management,Show files that WOULD be purged if $PURGE is done
				  NOPE

	Nope was born out of the need for a way to see what files would be
purged if a purge were done, and also show how many blocks would be made
available.  Nope should be set up as a symbol thusly;

		NOPE :==$SYS$MANAGER:NOPE

	Note that Nope may reside in any directory and requires no
privileges as long as the files to be referenced are not read protected
from the user.

	Nope works with the same file specification syntax as purge;

		NOPE			Look at current directory
		NOPE [...]		Look at current directory tree
		NOPE [*...]*.OBJ	Look at all .obj on this disk

	Nope lists directories as it checks them, but if you specify any part
of the filename or extension (*.obj, check.*) it only lists those directories
that contained files fitting that specification.  Nope also gives a grand
total at the end, including the number of files that would be purged and
the number of allocated blocks that would be freed.

	Nope has come in very handy in determining whether we should
schedule a global purge on our user disks.  Also, about the time you decide
to blindly purge a directory, you may find yourself in the wrong directory.  The
reason for the name Nope is that it is a subset of the words NOPurgE and also
I wanted to make it very different from PURGE (somebody suggested NOPURGE, but
sometimes my fingers think faster than my brain!).

	I hope that DEC will see this, and will somehow incorporate a similar
function into DCL.


********************************************************************************
* DISCLAIMER * DISCLAIMER * DISCLAIMER * DISCLAIMER * DISCLAIMER * DISCLAIMER * 

	Neither I nor the U.S. Geological Survey assume any responsibility
whatsoever for any use, misuse or abuse of this software.  This software is
provided with the intent that system managers will use it wisely to enhance
their systems.

* DISCLAIMER * DISCLAIMER * DISCLAIMER * DISCLAIMER * DISCLAIMER * DISCLAIMER * 
********************************************************************************


	EROS stands for Earth Resources Observation Systems and is not related
in any way with the skin mag of the same name.  We are a government agency
which primarily archives, enhances and sells products utilizing LANDSAT and
other remote sensing data.

	Written and submitted (to the DECUS SIG collection) by:

		Thomas Bodoh
		U.S.G.S. / EROS data center
		Mundt Federal Building
		Sioux Falls, SD  57198
		(605) 594-6830

=============================================================================        
May, 1997:

Submission note:   I've resurrected this nifty utility from the "VAX87C"
Fall 1987 VAX SIG DECUS tape.    It's a tool that I still use today, and
quite often I might add. 

I've successfully recompiled it under OpenVMS/Alpha V6.2-1H3, and the
original .EXE still runs under OpenVMS/VAX 6.2.

I've received permission from Tom to post this on the Freeware CD, with
the following notes:

A) Tom cannot in any way support this package (see original disclaimer
   above), as he no longer uses VMS systems, and

B) Tom now works for Hughes STX, not the USGS as noted in his original
   README file.    (for reference, his addr is bodoh@edcmail.cr.usgs.gov)

Enjoy.

Kent C. Brodie - Systems & Network Manager       Internet: <brodie@cpg.mcw.edu>
Medical College of Wisconsin	                 MaBellNet: +1 414 456 5080
Clinical Practice Group         (http://www.cpg.mcw.edu/www/staff/brodie.html)
      "Keep your hands and feet inside the ride at all times..."
