<?php
/*
  $Id: define_language.php,v 1.6 2002/01/17 11:41:26 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Sprache definieren');

define('TEXT_FILE_DOES_NOT_EXIST', 'Datei nicht vorhanden.');

define('ERROR_FILE_NOT_WRITEABLE', 'Fehler: Die Datei ist schreibgesch&uuml;tzt. Bitte korrigieren Sie die Zugriffsrechte f&uuml;r: %s');
?>