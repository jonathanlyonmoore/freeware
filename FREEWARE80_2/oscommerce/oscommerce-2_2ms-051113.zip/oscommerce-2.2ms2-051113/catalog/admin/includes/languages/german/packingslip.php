<?php
/*
  $Id: packingslip.php,v 1.2 2002/06/15 13:01:56 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Kommentar');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Artikel-Nr.');
define('TABLE_HEADING_PRODUCTS', 'Artikel');

define('ENTRY_SOLD_TO', 'Rechnungsanschrift:');
define('ENTRY_SHIP_TO', 'Lieferanschrift:');
define('ENTRY_PAYMENT_METHOD', 'Zahlungsweise:');
?>