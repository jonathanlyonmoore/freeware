<?php
/*
  $Id: stats_products_purchased.php,v 1.7 2002/03/30 14:59:36 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'meist verkaufte Artikel');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_PRODUCTS', 'Artikel');
define('TABLE_HEADING_PURCHASED', 'verkaufte Anzahl');
?>