<?php
/*
  $Id: secpay.php,v 1.7 2002/11/18 14:45:29 project3000 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_SECPAY_TEXT_TITLE', 'SECPay');
  define('MODULE_PAYMENT_SECPAY_TEXT_DESCRIPTION', 'Credit Card Test Info:<br><br>CC#: 4444333322221111<br>Expiry: Any');
  define('MODULE_PAYMENT_SECPAY_TEXT_ERROR', 'Credit Card Error!');
  define('MODULE_PAYMENT_SECPAY_TEXT_ERROR_MESSAGE', 'There has been an error processing your credit card. Please try again.');
?>