<?php
/*
  $Id: product_reviews_write.php,v 1.7 2003/06/05 23:23:52 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');

define('SUB_TITLE_FROM', 'From:');
define('SUB_TITLE_REVIEW', 'Your Review:');
define('SUB_TITLE_RATING', 'Rating:');

define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>NOTE:</b></font></small>&nbsp;HTML is not translated!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>BAD</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>GOOD</b></font></small>');

define('TEXT_CLICK_TO_ENLARGE', 'Click to enlarge');
?>
