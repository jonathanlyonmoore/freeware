<?php
/*
  $Id: products_new.php,v 1.3 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'New Products');
define('HEADING_TITLE', 'New Products');

define('TEXT_DATE_ADDED', 'Date Added:');
define('TEXT_MANUFACTURER', 'Manufacturer:');
define('TEXT_PRICE', 'Price:');
?>