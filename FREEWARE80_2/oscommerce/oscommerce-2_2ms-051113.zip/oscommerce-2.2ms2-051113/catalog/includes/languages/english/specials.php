<?php
/*
  $Id: specials.php,v 1.7 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Specials');
define('HEADING_TITLE', 'Get Them While They\'re Hot!');
?>
