<?php
/*
  $Id: product_info.php,v 1.15 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_PRODUCT_NOT_FOUND', 'No encontrado!');
define('TEXT_CURRENT_REVIEWS', 'Comentarios:');
define('TEXT_MORE_INFORMATION', 'Para obtener m&aacute;s informaci&oacute;n, visite la <a href="%s" target="_blank"><u>p&aacute;gina</u></a> del producto.');
define('TEXT_DATE_ADDED', 'Este producto esta en nuestro cat&aacute;logo desde %s.');
define('TEXT_DATE_AVAILABLE', '<font color="#ff0000">Este producto estar&aacute; disponible el %s.</font>');
define('TEXT_ALSO_PURCHASED_PRODUCTS', 'Clientes que compraron este producto, tambi&eacute;n han comprado');
define('TEXT_PRODUCT_OPTIONS', 'Opciones:');
define('TEXT_CLICK_TO_ENLARGE', 'Haga Click para agrandar');
?>
