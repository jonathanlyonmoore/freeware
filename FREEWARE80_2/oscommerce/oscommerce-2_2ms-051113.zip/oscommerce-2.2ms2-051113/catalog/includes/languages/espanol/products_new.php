<?php
/*
  $Id: products_new.php,v 1.4 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Novedades');
define('HEADING_TITLE', 'Novedades');

define('TEXT_DATE_ADDED', 'Fecha Alta:');
define('TEXT_MANUFACTURER', 'Fabricante:');
define('TEXT_PRICE', 'Precio:');
?>