<?php
/*
  $Id: address_book.php,v 1.15 2003/07/11 09:04:22 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Ihr Konto');
define('NAVBAR_TITLE_2', 'Adressbuch');

define('HEADING_TITLE', 'Mein Pers&ouml;nliches Adressbuch');

define('PRIMARY_ADDRESS_TITLE', 'Standardadresse');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Diese Adresse wird automatisch als Liefer- und Rechnungsadresse gew&auml;hlt wenn Sie eine Bestellung aufgeben.<br><br>Diese Adresse wird auch als Basis f&uuml;r die Berechnung eventueller Steuern udn Versandkosten verwendet.');

define('ADDRESS_BOOK_TITLE', 'Adressbucheintr&auml;ge');

define('PRIMARY_ADDRESS', '(Standardadresse)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>Hinweis:</b></font> Ihnen stehen %s Adressbucheintr&auml;ge zur Verf&uuml;gung!');
?>
