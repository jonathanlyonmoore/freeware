/*
 * pcalglob.h - definitions and declarations of globals used throughout Pcal
 *
 * Revision history:
 *
 *	4.5	AWR	02/05/93	Added support for -# flag (multiple
 *					copies of output page)
 *
 *		AWR	11/16/92	Use common "protos.h" file (q.v.)
 *
 *	4.4	AWR	01/20/92	Added support for -z flag and revised
 *					-[bgGO]
 *
 *	4.3	AWR	12/05/91	Add global "progpath" (used when
 *					searching for moon file)
 *
 *		AWR	12/03/91	Added support for -s flag
 *
 *	4.2	AWR	10/08/91	Added support for -[kK] flags
 *
 *		AWR	10/02/91	Added support for -c, -N, -S flags
 *
 *	4.1	AWR	07/16/91	Added support for -G flag
 *
 *	4.0	AWR	01/28/91	Added support for -b and -w flags
 *
 *		AWR	01/15/91	Extracted from pcal.c
 *
 */

#include "protos.h"

/*
 * Definitions and/or declarations of globals
 */

#ifdef MAIN_MODULE

/*
 * Misc. globals
 */

year_info *head = NULL;		/* head of internal data structure */
int curr_year;			/* current default year for date file entries */
char *words[MAXWORD];		/* maximum number of words per date file line */
char lbuf[LINSIZ];		/* date file source line buffer */
char progname[STRSIZ];		/* program name (for error messages) */
char progpath[STRSIZ];		/* directory where executable lives */
char version[20];		/* program version (for info messages) */

/* lengths and offsets of months in common year */
char month_len[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
short month_off[12] = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};

/* dispatch table for wildcard matching routines - cf. pcaldefs.h */
#ifdef PROTOS
int (*pdatefcn[])(int, int, int) = {
#else
int (*pdatefcn[])() = {
#endif
	is_anyday, is_weekday, is_workday, is_holiday, not_weekday, not_workday,
	not_holiday, is_newmoon, is_firstq, is_fullmoon, is_lastq
	};

/*
 * Default values for command-line options:
 */

char default_color[] = DAY_COLOR; 	/* -b, -g, -G, -O */
char day_color[7];
int holiday_color;
int weekday_color = WEEKDAY_COLOR;

int datefile_type = SYS_DATEFILE;	/* -e, -f */
char datefile[STRSIZ] = "";

int rotate = ROTATE;			/* -l, -p */

int draw_moons = DRAW_MOONS;		/* -m, -M */

char datefont[STRSIZ] = DATEFONT;	/* -d, -t, -n */
char titlefont[STRSIZ] = TITLEFONT;
char notesfont[STRSIZ] = NOTESFONT;

int mapfonts = MAPFONTS;		/* -r */

char shading[STRSIZ] = SHADING;		/* -s */

char lfoot[STRSIZ] = LFOOT;             /* -L, -C, -R */
char cfoot[STRSIZ] = CFOOT;
char rfoot[STRSIZ] = RFOOT;

char notes_hdr[STRSIZ];			/* -N (initialized in main()) */

int first_day_of_week = FIRST_DAY;	/* -F */

int date_style = DATE_STYLE;		/* -A, -E */

char outfile[STRSIZ] = OUTFILE;		/* -o */

char xsval[VALSIZ] = XSVAL;		/* -x, -y, -X, -Y */
char ysval[VALSIZ] = YSVAL;
char xtval[VALSIZ] = XTVAL;
char ytval[VALSIZ] = YTVAL;

int julian_dates = JULIAN_DATES;	/* -j */

int do_whole_year = DO_WHOLE_YEAR;	/* -w */

int calendar_out = CALENDAR_OUT;	/* -c */

int blank_boxes = BLANK_BOXES;		/* -B */

char ncopy[VALSIZ] = NCOPY;		/* -# */

int small_cal_pos = SMALL_CAL_POS;	/* -k, -K, -S */
int prev_cal_box[4] = PREV_CAL_BOX;
int next_cal_box[4] = NEXT_CAL_BOX;

char time_zone[STRSIZ] = TIMEZONE;	/* -z */
double utc_offset;
int tz_flag = FALSE;

int debug_flags = 0;			/* -Z */

#else

/*
 * Misc. globals
 */

extern year_info *head;		/* head of internal data structure */
extern int curr_year;		/* current default year for date file entries */
extern char *words[];		/* maximum number of words per date file line */
extern char lbuf[];		/* date file source line buffer */
extern char progname[];		/* program name (for error messages) */
extern char progpath[];		/* directory where executable lives */
extern char version[];		/* program version (for info messages) */

/* lengths and offsets of months in common year */
extern char month_len[];
extern short month_off[];

/* dispatch functions and table for wildcard processing */
#ifdef PROTOS
extern int (*pdatefcn[])(int, int, int);
#else
extern int (*pdatefcn[])(); 
#endif

/*
 * Default values for command-line options:
 */

extern char default_color[];	 	/* -b, -g, -G, -O */
extern char day_color[];
extern int holiday_color;
extern int weekday_color;

extern int datefile_type;		/* -e, -f */
extern char datefile[];

extern int rotate;			/* -l, -p */

extern int draw_moons;			/* -m, -M */

extern char datefont[];			/* -d, -t, -n */
extern char titlefont[];
extern char notesfont[];

extern int mapfonts;			/* -r */

extern char shading[];			/* -s */

extern char lfoot[];			/* -L, -C, -R */
extern char cfoot[];
extern char rfoot[];

extern char notes_hdr[];		/* -N */

extern int first_day_of_week;		/* -F */

extern int date_style;			/* -A, -E */

extern char outfile[];			/* -o */

extern char xsval[];			/* -x, -y, -X, -Y */
extern char ysval[];
extern char xtval[];
extern char ytval[];

extern int julian_dates;		/* -j */

extern int do_whole_year;		/* -w */

extern int calendar_out;		/* -c */

extern int blank_boxes;			/* -B */

extern char ncopy[];			/* -# */

extern int small_cal_pos;		/* -k, -K, -S */
extern int prev_cal_box[];
extern int next_cal_box[];

extern char time_zone[];		/* -z */
extern double utc_offset;
extern int tz_flag;

extern int debug_flags;			/* -Z */

#endif

