SCAN4 - DCL Command Output Scanning Facility
(c) Copyright 1994, Chris Olive and Siemens Medical Systems
------------------------------------------------------------------------------

SCAN4 was created because I got tired of doing  SHOW  WHATEVER/OUTPUT=X.X  and
searching  X.X  for  some  string,  often  forgetting to delete X.X afterward.
SCAN4 eliminates the need for an intermediate file and therefore is completely
transparent to the user.  SCAN4 requires no privileges other than TMPMBX.

Syntax:  SCAN4 ["]match-string["] DCL-command

SCAN4 accepts a match string as its first parameter.  Anything after the first
parameter is considered a DCL command.  SCAN4 works by sending the DCL command
given (after the  match  string)  to  a  sub-process  for  processing  in  the
background  (NOWAIT).   The  sub-process'  SYS$OUTPUT is directed to a mailbox
device which is created just ahead of the sub-process.  Once  the  sub-process
begins  and  its  output starts hitting the mailbox device, SCAN4 simply reads
the ensueing records from the mailbox,  scans  them  for  matching  text,  and
prints  any matching lines.  It's that simple.  No more X.X or other temporary
files laying around after the process.  There's nothing to delete.  All output
is simply filtered through a mailbox and that's it.

SCAN4 is *not* designed to handle complex expressions, do fancy  high-lighting
on  matches,  or display matches in "windows" (i.e.  like SEARCH/WINDOW).  Its
sole search "engine" is the assembly operand MATCHC.  Therefore, SCAN4 matches
only  on  exact text.  Maybe a future version will do fancy things like SEARCH
and Unix's grep command (I can't believe I said the "U" word).

Try SCAN4 out on a few things like this:

$ SCAN4 NET SHOW SYSTEM ! Scans for DECnet process in SHOW SYSTEM command
$ SCAN4 TNA SHOW USERS/FULL/INTER ! Scans for all users coming in on TNA terms
$ SCAN4 ", stopped" SH QUEUE/FULL ! Which queues are stopped right now?

Suppose you have Hunter Goatley's STB program assigned as a foreign symbol:

$ SCAN4 CLI STB ! Scan for all CLI related symbols in output of STB

Got a custom program for displaying things?  I have tons of them, and they all
work  with  SCAN4.   Most  folks  have a FINGER program of some sort which can
display current running images.  How about displaying all folks  running  MAIL
right now?

$ SCAN4 " MAIL" FINGER  ! Everyone running MAIL on this system
$ SCAN4 " 4096" @UTILS:WORKSET ! Scan for 4096 figure in WORKSET.COM output
$ SCAN4 "Smith" @ACCT:BILLABLES ! Scan for Smiths in output of BILLABLES.COM

$ MCP :== $MX_EXE:MCP ! For people running MadGoat's MX -- highly recommended!
$ SCAN4 "olive" MCP QUEUE SHOW/ALL ! Find me in MX message queue
$ SCAN4 FINISH MCP QUEUE SHOW/ALL  ! Show all FINISHed MX entries
$ SCAN4 "compuserve.com" MCP QUEUE SHOW/ALL ! Any CompuServe mail in or out?

$ SCAN4 "/user12" UCX SHOW BIND ! Is /user12 in the UCX bind table?

See, SCAN4 can help you "customize" or reduce (for you databasers  out  there)
the output you see from even your own custom-written or site-specific programs
ON THE SPOT, ad-hoc.  (Most folks never think of the SHOW SYSTEM command as  a
table, but with SCAN4 it is!)

Here's something I want to do on occasion:  find all users with a certain file
open on a device using SHOW DEVICE/FILE/NOSYSTEM.  It's easy with SCAN4:

$ SCAN4 SYSUAF SHOW DEVICE/FILE/NOSYSTEM SYS$SYSDEVICE ! Show SYSUAF users

How about these for the programmer types:

$ ! Scan for all the byte specific synbols in $UCBDEF
$ SCAN4 $B_ LIBRARY/OUTPUT=SYS$OUTPUT/EXTRACT=$UCBDEF/MACRO SYS$LIBRARY:LIB
$ ! Scan for all symbols in $UCBDEF with BUF in the symbol name
$ SCAN4 BUF LIBRARY/OUTPUT=SYS$OUTPUT/EXTRACT=$UCBDEF/MACRO SYS$LIBRARY:LIB

Or these:

$ SCAN4 JERKFACE.MAR CMS SHOW ELEMENTS ! Is JERKFACE.MAR in current CMS lib?
$ SCAN4 CMKRNL SHOW PROC/PRIV ! Hey, do I have CMKRNL on?
$ SCAN4 DISK$ SH LOG/SYS      ! Show DISK$ string found in *both* logicals
$                             ! *and* equivalance strings in LNM$SYSTEM table

Ever tried to find all the nodes in NCP which matched a certain string?   Well
now you can with SCAN4...

$ SCAN4 "(OPS" MCR NCP SHOW KNOWN NODES ! Find nodes whose name begins w/"OPS"

As you can imagine, there are many uses for SCAN4.  The  "read  from  mailbox"
mechanism  is  fairly  fast.   The only overhead a few folks might see on some
slower processors is the overhead associated  with  creating  the  sub-process
"executor"  which  pipes  output  to  the  mailbox.   Once  the sub-process is
created, however, the mailbox I/O is pretty fast.

Since SCAN4 actually executes the DCL command given it in a sub-process, there
are  some  limitations to what it can do.  For instance, the SCAN4 CMKRNL SHOW
PROCESS/PRIV command above works only because the created sub-process inherits
all the privileges of its parent.  So, coincidentally, it works.  However, the
following command does not faithfully report the correct results:

$ SCAN4 "Buffered I/O" SH PROC/QUOTA

Buffered I/O is a pooled resource and therefore has a different value  once  a
sub-process  is  created.   Therefore, the above command, although it produces
output, does not work properly since it does not reflect  the  desired  result
which would presumably be the buffered I/O for the current process.

The  MACRO  source  file  will  assemble  (compile)  on  both  VAX   and   AXP
architectures.   A  BUILD  file is included for building SCAN4 from scratch as
well as a LINK procedure for simply relinking the  objects.   Explanation  can
also  be found in the source code for those who wish to build SCAN4 completely
from  scratch.   Object  and  executable  images   are   included   for   both
architectures.

Use SCAN4 at your own risk.  Neither I nor my employer can be or will be  held
responsible  for  any  damages  which  result from the use or misuse of SCAN4.
Other than that, have fun!

_______________________________________________________________________________
    ___  ___  ___ _   _  ___ _  _  ___                                         
   /___   |  |__  |\ /| |__  |\ | /___    Chris Olive, VMS Systems Consultant   
   ___/  _|_ |___ | Y | |___ | \| ___/       Internet: olive@sgi.siemens.com   
           Medical Systems, Inc.                Voice: 708.304.7793            
         2501 N. Barrington Road.                 FAX: 708.304.7704            
        Hoffman Estates, IL  60195         CompuServe: 73740,1636              
_______________________________________________________________________________
