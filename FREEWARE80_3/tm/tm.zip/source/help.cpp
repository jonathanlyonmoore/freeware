# 1 "help.c"




 













































































# 1 "GNU_CC_INCLUDE:[000000]stdio.h" 1 3
 





 




 





 


struct	_iobuf 	{
	int	_cnt;			 
	char	*_ptr;			 
	char	*_base;			 
	char	_flag;			 








	char	_file;			 
	};

 



typedef struct _iobuf *FILE;

 




extern FILE *stdin __asm("_$$PsectAttributes_NOSHR$$stdin");
extern FILE *stdout __asm("_$$PsectAttributes_NOSHR$$stdout");
extern FILE *stderr __asm("_$$PsectAttributes_NOSHR$$stderr");

 







 











 


FILE	*fopen();
FILE	*fdopen();
FILE	*freopen();
char	*fgets();
long	ftell();


# 83 "help.c" 2

# 1 "GNU_CC_INCLUDE:[000000]string.h" 1 3
# 1 "GNU_CC_INCLUDE:[000000]strings.h" 1 3
 


char	*strcat();
char	*strncat();
int	strcmp();
int	strncmp();
char	*strcpy();
char	*strncpy();



char	*index();
char	*rindex();
# 1 "GNU_CC_INCLUDE:[000000]string.h" 2 3

# 84 "help.c" 2

# 1 "GNU_CC_INCLUDE:[000000]ctype.h" 1 3
 












extern	const char _ctype_[];

 




int __gnu_xyzzy_foobar __asm("_$$PsectAttributes_GLOBALSYMBOL$$c$v_ctypedefs");
 
 

















# 85 "help.c" 2

# 1 "GNU_CC_INCLUDE:[000000]stdlib.h" 1 3
 

 

























void volatile _exit(int);
void volatile abort(void);
int       abs(int);
int       access(const char*, int);
 
unsigned  alarm(unsigned);
double    atof(const char*);
int       atoi(const char*);
long      atol(const char*);
 
int       brk(void*);
int       bsearch (const void *, const void *, unsigned long, 
                   unsigned long, int (*ptf)(const void*, const void*));
void*     calloc(unsigned, unsigned);
void      cfree(void*);
int       chdir(const char*);
int       chmod(const char*, int);
int       chown(const char*, int, int);
long      clock(void);
int       close(int);
int       creat(const char*, unsigned long int);
 
char*     ctermid(char*);
char*     cuserid(char*);
 
int       dup(int);
int       dup2(int, int);
 
char*     ecvt(double, int, int*, int*);
 
double    erand(short*);
 



int       execv(const char*,  const char**);
int       execve(const char*, const char**, char**);
 
void volatile exit(int);
 
 
 
char*     fcvt(double, int, int*, int*);
 
 
 
void      free(void*);
 
 
 
char*     gcvt(double, int, char*);
char*     getcwd(char*, int);
 
 
int       getegid(void);
char*     getenv(const char*);
int       geteuid(void);
int       getgid(void);
 
 
 
 
 
 
 
 
int       getpid(void);
int       getppid(void);
 
 
unsigned  getuid(void);
 
 
 
int       isatty(int);
 
int       kill(int, int);
 
 
 
 
 
 
long      lseek(int, long, int);
void*     malloc(unsigned);
 
 
 
void*     memchr(const void*, int, int);
 
 
void*     memset(void*, int, int);
int       mkdir(const char*, int);
 
 
char*     mktemp(char*);
 
int       nice(int);
 
int       open(const char*, int, ...);
void volatile pause(void);
void      perror(const char*);
int       pipe(int*);
 
 
 
 
int       qsort(void*, int, unsigned, int (*ptf)(void*,void*));
int       rand(void);
 
int       read(int, void*, unsigned);
 
void*     realloc(void*, unsigned);
int       rename(const char*, const char*);
 
void*     sbrk(int);              
 
 
int       setgid(int);
 
 
 
 
 
 
 
int       setuid(int);
int       sigblock(int);
 
int       sigpause(int);
int       sigsetmask(int);
unsigned  sleep(unsigned);
 
int       srand(int);
 
 
 
char*     strcat(char*, const char*);
char*     strchr(const char*, int);
int       strcmp(const char*, const char*);
char*     strcpy(char*, const char*);
int       strcspn(const char*, const char*);
 
 
char*     strncat(char*, const char*, int);
int       strncmp(const char*, const char*, int);
char*     strncpy(char*, const char*, int);
char*     strpbrk(const char*, const char*);
char*     strrchr(const char*, int);
int       strspn(const char*, const char*);
double    strtod(const char*, char**);
char*     strtok(char*, const char*);
long      strtol(const char*, char**, int);
 
 
 
int       system(const char*);
 
 
 
 
 
 
long      time(long*);
 
 
 
char*     ttyname(int);
 
 
 
int       umask(int);
 
 
 
 
int       vfork(void);
 
int       wait(int*);
int       write(int, const void*, unsigned);


int       bcmp(const void*, const void*, int);
void      bcopy(const void*, void*, int);
void      bzero(void*, int);
char*     index(const char*, int);
char*     rindex(const char*, int);

extern char**   environ;
extern volatile int errno;
extern char*    sys_errlist[];
extern int      sys_nerr;                  
extern char*    optarg;
extern int      opterr;
extern int      optind;
















# 86 "help.c" 2








 
struct item_node
      {
      char *name;           
      char *path;           
      char *item;                     
      struct item_node *sibptr;       
      struct item_node *firstsibptr;  
      struct item_node *parentptr;    
      struct item_node *childptr;     
      int status;           
      };

struct item_node root;                
struct item_node *rptr = &root;       

char answer[30 ];               


 

 
char getlin(FILE *fptr, char *buff, int lim)
      {
      char c;
      int i;

      i = 0;
      while (--lim > 0 && (c=	fgetc(fptr) ) != 	(-1)  && c != '\n')
        buff[i++] = c;
      if (c == '\n')
        buff[i++] = c;
      buff[i] = '\0';
      return(c);
      }

 

struct item_node *makenode (int new_level, char *linebuf)
      {
      struct item_node *new_node;
      char nambuf[30 ], pathbuf[90 ];
      static char namestack[10][30 ];
      int i,j;

      new_node = (struct item_node *) malloc(sizeof(struct item_node));

      new_node->sibptr = 	0 ;
      new_node->firstsibptr = 	0 ;
      new_node->childptr = 	0 ;
      new_node->parentptr = 	0 ;
      new_node->item = 	0 ;
      new_node->status = 1;

       

      for (i=1; linebuf[i]==' '; i++);    
      j = 0;
      while (linebuf[i] != ' ' && linebuf[i] != '\0' && linebuf[i] != 10 )

        nambuf[j++] = ((linebuf[i++])-'a'+'A') ;



      nambuf[j] = '\0';
      new_node->name = (char *) malloc(strlen(nambuf)+1);
      strcpy(new_node->name,nambuf);

       

      strcpy( namestack[new_level], nambuf);   
      strcpy (pathbuf, namestack[1]);    
      for (i=2; i<=new_level; i++)                     
        {
        strcat(pathbuf," ");
        strcat(pathbuf, namestack[i]);
        }
      new_node->path = (char *) malloc(strlen(pathbuf)+1);
      strcpy(new_node->path,pathbuf);

      return(new_node);
      }


 

void insertion_sort(struct item_node *firstptr, struct item_node *newptr)
      {
      struct item_node *cursor;
      struct item_node *saveptr;
      struct item_node *previous;
      
 
      if (strcmp(newptr->name,firstptr->name) < 0)
        {
        cursor = saveptr = firstptr;
 
        while(cursor != 	0 )
          {
          cursor->firstsibptr = newptr;
          cursor = cursor->sibptr;
          }        
        saveptr->parentptr->childptr = newptr;
        newptr->sibptr = saveptr;
        newptr->firstsibptr = newptr;
        return;
        }
 
      newptr->firstsibptr = firstptr;
      cursor = firstptr->sibptr;
      previous = firstptr;
      while (cursor != 	0 )
        {
        if (strcmp(newptr->name,cursor->name) < 0)
          {
          previous->sibptr = newptr;
          newptr->sibptr = cursor;
          return;
          }
        cursor = cursor->sibptr;
        previous = previous->sibptr;
        }
      previous->sibptr = newptr;
      return;
      }

 

void maketree(char *filname, struct item_node *rptr)
      {
      FILE *fptr;
      char linebuf[90 ], getlin(FILE*,char*,int);
      char filn[30 ];
      struct item_node *current_item, *new_branch;
      char itembuf[8192   ];   
      int current_level, number_back;
      int i, count, truncated=0;

      strcpy(filn,filname);

 
      if ( strchr(filn,'.') == 0 )
          strcat(filn,".hlp");

      if((fptr = fopen(filn,"r")) == 	0 )
        {
        printf("The help utility can't read file %s\n",filn);
        return;
        }

      current_level = 0;
      current_item  = rptr;    
      itembuf[0] = '\0';
      count = 0;

      while(1)
        {

         
        if (getlin(fptr, linebuf, 90 ) == 	(-1) )
          {
          if (strlen(itembuf) == 0)
            {
            current_item->item = (char *) malloc(1);
            current_item->item[0] = '\0';
            }
          else
            {
            itembuf[strlen(itembuf) - 1] = '\0';   
            if (truncated)
              {
              truncated = 0;
              current_item->status = 0;
              printf("-- help info for %s was truncated\n",current_item->path);
              strcat(itembuf,"\n\n       << truncated >>");
              }
            current_item->item = (char *) malloc(strlen(itembuf));
            strcpy(current_item->item,itembuf);
            }
          if (truncated)
            {
            truncated = 0;
            current_item->status = 0;
            printf("-- help info for %s was truncated\n",current_item->path);
            strcat(current_item->item,"\n\n       << truncated >>");
            }
          itembuf[0] = '\0';
          count = 0;
          break;
          }

         
        else if (linebuf[0] == '!' || linebuf[0] == '#')   
          continue; 

         
        else if ((_ctype_[(linebuf[0]) & 0x7f] & 04 )  && linebuf[1] == ' ')   
          {  
          if (strlen(itembuf) == 0)
            {
            current_item->item = (char *) malloc(1);
            current_item->item[0] = '\0';
            }
          else
            {
            itembuf[strlen(itembuf) - 1] = '\0';
            if (truncated)
              {
              truncated = 0;
              current_item->status = 0;
              printf("-- help info for %s was truncated\n",current_item->path);
              strcat(itembuf,"\n\n       << truncated >>");
              }
            current_item->item = (char *) malloc(strlen(itembuf));
            strcpy(current_item->item,itembuf);
            }
          itembuf[0] = '\0';
          count = 0;

           
          if (atoi(linebuf) == current_level)
            {
            new_branch = makenode(current_level,linebuf);
            new_branch->parentptr = current_item->parentptr;



            current_item->sibptr = new_branch;
            new_branch->firstsibptr = current_item->firstsibptr;

            current_item = new_branch;                     
            }
          else if (atoi(linebuf) == current_level + 1)
            {
            current_level++;
            if (current_level == 9)
              printf("help levels higher than 9 are not supported.\n");
            new_branch = makenode(current_level,linebuf);
            new_branch->parentptr = current_item;
            current_item->childptr = new_branch;
            new_branch->firstsibptr = new_branch;
            current_item = new_branch;
            }
          else if (atoi(linebuf) < current_level )
            {
            number_back = current_level - atoi(linebuf);
            current_level -= number_back;
            new_branch = makenode(current_level,linebuf);
            for (i=0; i<number_back; i++)
              current_item = current_item->parentptr;
            new_branch->parentptr = current_item->parentptr;



            current_item->sibptr = new_branch;
            new_branch->firstsibptr = current_item->firstsibptr;

            current_item = new_branch;                             
            }

          else
            printf("invalid key\n");
          }

         
        else
          {
          count += strlen(linebuf);
          if ( count < 8192    - 3*90  )
            strcat(itembuf,linebuf);
          else
            truncated = 1;
          }
        }
      fclose(fptr);
      return;
      }

 

void show_subtopics(struct item_node *itemptr)
      {
      struct item_node *cursor;
      int i, count, wordlen, numfield, filler;

      cursor = itemptr->childptr;

      printf("\n-----additional help available for: \n");
      printf("       ");
      count = 7;
      while(cursor != 	0 )
        {
        wordlen = strlen(cursor->name);

 

        numfield = 1 + wordlen / 10         ;     
        filler = numfield * 10          - wordlen;   

        if ( (count + numfield*10         ) >= 80)
          {                          
          printf("\n       ");
          count = 7;
          }
        count += numfield*10         ;

         
        printf("%s",cursor->name);
        for (i=1; i<=filler; i++)
          printf(" ");

        cursor = cursor->sibptr;
        }
      }


 

struct item_node *find_item(struct item_node *ptr, char *name)
      {
      struct item_node *cursor;
      int i,okay;

      if (ptr->childptr == 	0 )
        return (	0 );

      cursor = ptr->childptr;

 
      while (cursor != 	0 )
        {
        i = 0;
        okay = 1;
        while (  name[i] != '\0')
          {
          if ( cursor->name[i] != name[i] || cursor->name[i] == '\0' )
            {
            okay = 0;
            break;
            }
          i++;
          }
        if (okay == 1)
          return(cursor);
        cursor = cursor->sibptr;
        }

      return (	0 );
      }


 


void get_help(char *itemstring)
      {
      char NextItemString[90 ];
      char itemstringbuf[90 ];    
      struct item_node *itemptr, *saveptr;
      static struct item_node;
      char *itemword;
      int i, count;
      static int firstcall=1;

      i = 0;
      while( itemstring[i] != '\0')
        {

        itemstringbuf[i] = ((itemstring[i])-'a'+'A') ;



        i++;
        }
      itemstringbuf[i] = '\0';

 


















       

      itemptr = rptr;     
      itemword = strtok(itemstringbuf," ");
      while (itemword != 	0 )
        {
        saveptr = itemptr;
        itemptr = find_item(itemptr,itemword);
        if (itemptr == 	0 )
          {
          printf("\n\n-----there's no help for: %s %s\n",
                    saveptr->path,itemword);
          return;
          }
        itemword = strtok(	0 ," ");
        }

   

      printf("\n**** %s ****\n%s\n",itemptr->path,itemptr->item);

   

      if ( itemptr->childptr != 	0  )
        show_subtopics(itemptr);

   

      while(1)
        {
        printf("\nsubtopic?> ");
        getlin(stdin,answer, 30 );
        answer[strlen(answer)-1] = '\0'; 
        if (strcmp(answer,"?")==0)
          {
          printf("\n**** %s ****\n%s\n",itemptr->path,itemptr->item);
          if ( itemptr->childptr != 	0  )
            show_subtopics(itemptr);
          }
        else if (strlen(answer) == 0)     
          return;
        else         
          {
          strcpy(NextItemString,itemptr->path);
          strcat(NextItemString," ");
          strcat(NextItemString,answer);     
          get_help(NextItemString);
          printf("\n**** %s ****\n",itemptr->path);
          if ( itemptr->childptr != 	0  )
            show_subtopics(itemptr);
          }
        }
      }


 



init_help(char *fname)
      {
 
      rptr->sibptr = 	0 ;
      rptr->parentptr = 	0 ;
      rptr->childptr = 	0 ;
      rptr->status = 1;
      rptr->item = 	0 ;
      rptr->name = (char *) malloc(10);
      rptr->path = (char *) malloc(10);
      strcpy(rptr->name,"");
      strcpy(rptr->path,"");

 

      maketree(fname,rptr);

      }
