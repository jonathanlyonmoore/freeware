TQE V2.1
Written by Lee Gleason way back in 1984? 1985?

Ported to OpenVMS Alpha by Hunter Goatley, 1996, 1998, 2000

TQE displays the Timer Queue Entries (TQEs) for a system.  Very handy
for checking to see whether or not an AST is scheduled to be fired for
a process at some future time.
