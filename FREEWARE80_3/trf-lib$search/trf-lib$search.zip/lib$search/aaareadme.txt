Date: Sat, 07 Jun 2003 09:28:42 -0700 (MST)
From: "Terry R. Friedrichsen" <terry@uplift.sunquest.com>

Hunter,

Here's the code I promised you last night.  I cleaned it up a bit from its
original (1989!) version, because I like the code I write now better than
I like the code I wrote then :-).

testsearch.c is a test program that calls lib$search() in libsearch.c.
(Fortunately, VMS seems not to have acquired a lib$search() function of
its own in the intervening 14 years).  The function name could probably
be better-chosen.

lib$search() uses RMS $SEARCH to return file names, but places series' of
identical filenames on a stack so it can return them to the caller in in-
creasing version-number order rather than in decreasing order as $SEARCH
does.

It is called just as $SEARCH, with the address of a $PARSEd FAB, but does
not support the optional error and success ASTs.

I retested, since I hacked on it this morning, and it seems to work cor-
rectly under VMS 6.2, 7.1, and 7.3.

Terry R. Friedrichsen
terry@uplift.sunquest.com
