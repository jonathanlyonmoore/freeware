#include <stdio.h>
#include <stdlib.h>

#include <rms.h>

#include <starlet.h>
#include <lib$routines.h>

#define FILESPECLEN	252
static char search_esa[FILESPECLEN + 1];
static char search_rsa[FILESPECLEN + 1];

extern long lib$search(struct FAB *);



main()

{
  struct FAB search_fab;
  struct NAM search_nam;
  long rms_status;

  search_fab = cc$rms_fab;
  search_fab.fab$l_fna = "*.*;*";
  search_fab.fab$b_fns = sizeof "*.*;*" - 1;

  search_nam = cc$rms_nam;
  search_nam.nam$b_ess = FILESPECLEN;
  search_nam.nam$l_esa = search_esa;
  search_nam.nam$b_rss = FILESPECLEN;
  search_nam.nam$l_rsa = search_rsa;

  search_fab.fab$l_nam = &search_nam;

  rms_status = sys$parse(&search_fab);
  if (rms_status != RMS$_NORMAL) {
    printf("error parsing filespec\n");
    exit(rms_status);
  }

  while ((rms_status = lib$search(&search_fab)) == RMS$_NORMAL) {
    search_rsa[search_nam.nam$b_rsl] = '\0';
    printf("resultant string was %s\n", search_nam.nam$l_rsa);
  }

  exit(rms_status);
}
