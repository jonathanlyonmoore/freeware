TSCON - a terminal server utility (V4.1b)		30-APR-1993
=========================================

This communicates with the remote console port of DEC terminal servers
using MOP, allowing remote management of terminal servers.

It can be used like SET HOST for an interactive session, or can be used to
execute a script from a file, or a single command from the command line.

It can log into a terminal server automatically in privileged state,
greatly simplifying the management of terminal servers.

It needs a DECnet Ethernet circuit to be running - it uses the controller
that DECnet is using. The terminal server has to be registered in either the
DECnet volatile database or in TSCON's own database.

TSCON's interactive mode is slightly different if used on a SET HOST
(RTAn) terminal as the driver does not implement all of TTDRIVER's features.

Future plans include implementing parameters in scripts and other features
similar to DEC's TSM.

See TSCON.HLP for further details.


Known problems:

There is a problem with the DEChub family of products (e.g. DECserver 90)
in that the normal /MODE=CHARACTER does not work. /MODE=LINE has to be
used and the sequence "CTRL/P <Return>" to disconnect.
Also /LOGIN does not work.


Ian Kitching,
System Manager,				Tel. +44 223 63271  ext. 2278
Computer Services,			Fax  +44 223 352973
Anglia Polytechnic University,		JANet systimk@uk.ac.anglia.va
East Road,
Cambridge  CB1 1PT
England
