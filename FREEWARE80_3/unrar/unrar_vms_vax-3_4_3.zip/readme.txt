Hello!

This is OpenVMS 7.2 VAX port regards to OpenVMS Alpha one.
To compile it under VAX DEC C++ 5.6 I had to change many lines like
for (int i;...;...)

to

int i;

for (i;....;)

I dont know why.

Also, gnv for VAX is buggy (?),
cxx returns SYS$INPUT:BLABLA.OPT write error,
and I create unrar.lib from objects, then
use cxxlnk command to link it by hands.
So, no any makefiles, command files yet.

Well, I get unrar.exe.
This version can unpack *.rar, *.exe archives, include multivolume ones.
Multivolume names must be converted from arch.part1.rar to arch.part1-rar,
arch.part2.rar to arch.part2-rar, etc.

