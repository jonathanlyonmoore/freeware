#define RARVER_MAJOR     3
#define RARVER_MINOR    60
#define RARVER_BETA      7
#define RARVER_DAY      13
#define RARVER_MONTH     7
#define RARVER_YEAR   2006
