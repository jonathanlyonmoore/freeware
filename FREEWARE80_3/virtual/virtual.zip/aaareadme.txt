VIRTUAL - Device Virtual Terminal Enable/Disable Utility
(c) Copyright 1991, Defense Information Technology Services Org & Chris Olive
------------------------------------------------------------------------------

VIRTUAL simply enables or disables the TT2$M_DISCONNECT bit  of  any  terminal
device,   including   device   templates,  thereby  dynamically  enabling  (or
disabling) the creation of virtual terminals (assuming the VTA0:   device  has
been connected in SYSGEN/SYSMAN) WITHOUT REQUIRING A REBOOT OF THE SYSTEM.  If
VIRTUAL is used to enable a device  or  set  of  devices  (by  modifiying  the
associated  template  device)  then virtual terminals will be created for that
device (or set of devices) UPON THE  NEXT  LOGIN.   NO  REBOOTING.   Disabling
works the same way, but inreverse.

THIS SOFTWARE REQUIRES KERNEL MODE AND CARRIES WITH  IT  THE  STANDARD  KERNEL
MODE DISCLAIMER.  SEE THE COMMENT SECTION OF THE SOURCE FOR FULL DETAILS.

This software is unoffically dubbed "workware," not shareware and not freeware
per  se.   What that means is this:  I am most of the time open to extra work.
Therefore you can compensate me for  this  software  by  either  employing  me
sometime  or  pointing someone in my direction should they require a compotent
programmer for some reason.  (I know this code isn't that big a deal, but  did
you write it???  :-))

Enjoy!
Chris
-----
Chris Olive
46621 SR 46
New Waterford, OH 44445
E-mail: 73740.1636@compuserve.com
