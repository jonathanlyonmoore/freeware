VTfm,Utilities,OpenVMS File Manager for VT-series terminals
VTfm is a Norton Commander style file manager for Digital
VT-series terminals or terminal emulators which can emulate
such terminals (PowerTerm, for example). VTfm works under
OpenVMS on VAX, Alpha and IA64 processors.

Author: Vladimir K. Vershinin, Moscow, Russia
E-mail: vershinin-vk@tochka.ru
