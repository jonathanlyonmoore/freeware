print '''
<html>
	<head>
		<title>Hello</title>
	</head>
	<body>
		<p>Hello
	</body>
</html>'''
