# print "Loaded KidKit examples package."
