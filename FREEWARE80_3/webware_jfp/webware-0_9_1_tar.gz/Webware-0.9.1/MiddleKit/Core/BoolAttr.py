from BasicTypeAttr import BasicTypeAttr


class BoolAttr(BasicTypeAttr):
	pass
