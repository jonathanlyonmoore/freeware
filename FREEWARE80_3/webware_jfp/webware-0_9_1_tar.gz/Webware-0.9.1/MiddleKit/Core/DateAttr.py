from AnyDateTimeAttr import AnyDateTimeAttr


class DateAttr(AnyDateTimeAttr):
	def __init__(self, dict):
		AnyDateTimeAttr.__init__(self, dict)
