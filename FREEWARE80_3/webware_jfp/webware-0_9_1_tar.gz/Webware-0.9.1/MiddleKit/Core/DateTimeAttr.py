from AnyDateTimeAttr import AnyDateTimeAttr


class DateTimeAttr(AnyDateTimeAttr):
	def __init__(self, dict):
		AnyDateTimeAttr.__init__(self, dict)
