from AnyDateTimeAttr import AnyDateTimeAttr


class TimeAttr(AnyDateTimeAttr):
	def __init__(self, dict):
		AnyDateTimeAttr.__init__(self, dict)
