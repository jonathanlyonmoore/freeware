from SQLPythonGenerator import SQLPythonGenerator


class MySQLPythonGenerator(SQLPythonGenerator):
	pass
