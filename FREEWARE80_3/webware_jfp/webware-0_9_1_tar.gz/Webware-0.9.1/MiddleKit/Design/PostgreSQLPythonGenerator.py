from SQLPythonGenerator import SQLPythonGenerator


class PostgreSQLPythonGenerator(SQLPythonGenerator):
	pass
