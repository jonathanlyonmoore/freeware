
def InstallInWebKit(appserver):
    pass
