urlRedirect = {
    'dummy': 'whatever',
    'test1redir': 'test1',
    }
