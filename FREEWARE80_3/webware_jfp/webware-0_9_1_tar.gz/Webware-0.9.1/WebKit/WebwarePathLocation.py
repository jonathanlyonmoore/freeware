
# Used solely to have a module to import from a definite location
