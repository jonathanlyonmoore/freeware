# Deprecated: We used to be called WebFuncs, now just Funcs.

from Funcs import *
