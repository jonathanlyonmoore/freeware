# WebUtils package
# Webware for Python
# See ../README

__all__ = ['Cookie', 'HTMLForException', 'HTTPStatusCodes', 'HTMLTag', 'Funcs']


def InstallInWebKit(appServer):
	pass
